<?php
/**
 * @package  GalleryPlugin
 */

namespace Inc\Base;

use Inc\Api\SettingsApi;
use Inc\Api\Callbacks\AdminCallbacks;
use Inc\Api\Callbacks\BeautifulGalleriesCallbacks;

class BeautifulGalleriesController extends BaseController
{

    public $settings;
    public $callbacks;
    public $custom_post_types;
    public $BeautifulGalleries_callbacks;
    public $subpages = array();

    public function register(){

        if (!$this->activated('beautifulGalleries_manager')) return;

        $this->settings = new SettingsApi();
        $this->callbacks = new AdminCallbacks();
        $this->BeautifulGalleries_callbacks = new BeautifulGalleriesCallbacks();

        $this->setSubPages();
        $this->setSettings();
        $this->setSections();
        $this->setFields();

        $this->settings->addSubPages($this->subpages)->withSubPage()->register();

    }

    public function setSubPages(){

        $this->subpages = array(

            array(
                'parent_slug' => 'gallery_plugin',
                'page_title' => 'Beautiful Galleries',
                'menu_title' => 'Beautiful Galleries',
                'capability' => 'manage_options',
                'menu_slug' => 'beautifulGalleries_settings',
                'callback' => array($this->callbacks, "adminBeautifulGalleries"),
            ),

        );

    }

    public function setSettings(){

        $args = array(

            $args[] = array(
                'option_group' => 'gallery_plugin_beautifulGalleries_settings',
                'option_name' => 'beautifulGalleries_settings',
                'callback' => array($this->BeautifulGalleries_callbacks, 'BeautifulGalleriesSanitize')
            )

        );

        $this->settings->setSettings($args);

    }

    public function setSections(){

        $args = array(

            array(
                'id' => 'beautifulGalleries_index',
                'title' => 'Beautiful Gallery',
                'callback' => array($this->BeautifulGalleries_callbacks, 'BeautifulGalleriesSectionManager'),
                'page' => 'beautifulGalleries_settings'
            )

        );

        $this->settings->setSections($args);
    }


    public function setFields(){

        $args = array(

            array(
                'id' => 'beautiful_gallery_1_container',
                'title' => 'Enable Beautiful Gallery 1 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_1_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_2_container',
                'title' => 'Enable Beautiful Gallery 2 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_2_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_3_container',
                'title' => 'Enable Beautiful Gallery 3 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_3_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_4_container',
                'title' => 'Enable Beautiful Gallery 4 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_4_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_5_container',
                'title' => 'Enable Beautiful Gallery 5 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_5_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_6_container',
                'title' => 'Enable Beautiful Gallery 6 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_6_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_7_container',
                'title' => 'Enable Beautiful Gallery 7 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_7_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_8_container',
                'title' => 'Enable Beautiful Gallery 8 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_8_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_9_container',
                'title' => 'Enable Beautiful Gallery 9 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_9_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_10_container',
                'title' => 'Enable Beautiful Gallery 10 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_10_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_11_container',
                'title' => 'Enable Beautiful Gallery 11 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_11_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_12_container',
                'title' => 'Enable Beautiful Gallery 12 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_12_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_13_container',
                'title' => 'Enable Beautiful Gallery 13 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_13_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_14_container',
                'title' => 'Enable Beautiful Gallery 14 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_14_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_15_container',
                'title' => 'Enable Beautiful Gallery 15 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_15_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_16_container',
                'title' => 'Enable Beautiful Gallery 16 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_16_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_17_container',
                'title' => 'Enable Beautiful Gallery 17 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_17_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'beautiful_gallery_18_container',
                'title' => 'Enable Beautiful Gallery 18 ',
                'callback' => array($this->BeautifulGalleries_callbacks,'checkboxField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'beautiful_gallery_18_container',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'post_data',
                'title' => '',
                'callback' => array($this->BeautifulGalleries_callbacks,'textField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'post_data',
                )
            ),
            array(
                'id' => 'widgets',
                'title' => '',
                'callback' => array($this->BeautifulGalleries_callbacks,'textField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => 'widgets',
                )
            ),

        );

        $options = get_option('addGallery_settings') ?: array();

        foreach ($options as $option){
            $arr =  array(
                'id' => $option['gallery_title'],
                'title' => '',
                'callback' => array($this->BeautifulGalleries_callbacks,'textField'),
                'page' => 'beautifulGalleries_settings',
                'section' => 'beautifulGalleries_index',
                'args' => array(
                    'option_name' => 'beautifulGalleries_settings',
                    'label_for' => $option['gallery_title'],
                )
            );
            array_push($args, $arr);
        }

        $this->settings->setFields($args);

    }

}