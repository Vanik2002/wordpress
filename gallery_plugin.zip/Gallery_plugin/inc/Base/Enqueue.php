<?php
/**
 * @package  GalleryPlugin
 */

namespace Inc\Base;

class Enqueue extends  BaseController
{

    public function register(){
        add_action('admin_enqueue_scripts',array($this,'enqueue'));
        add_action('wp_head',array($this,'add_css'),0);
    }

    public function enqueue(){

        wp_enqueue_media();
        wp_enqueue_code_editor( array( 'type' => 'text/css' ) );
        wp_enqueue_style('my-plugin-style',$this->plugin_url . '/assets/myStyle.css');
        wp_enqueue_script( 'jquery' );
        wp_enqueue_script( 'wp-a11y' );
        wp_enqueue_script( 'wp-hooks' );
        wp_enqueue_script( 'code-editor');
        wp_enqueue_script('media-upload');
        wp_enqueue_script( 'wp-codemirror');
        wp_enqueue_script( 'wp-code-editor');
        wp_enqueue_script( 'jquery-ui-sortable');
        wp_enqueue_script( 'wp-theme-plugin-editor');
        wp_enqueue_script( 'wp-theme-plugin-editor' );
        wp_enqueue_script('my-plugin-script',$this->plugin_url . '/assets/myScript.js');

    }

    function add_css(){

        include $this->plugin_path. "templates/global_settings/globalSettingsStyles.php";

    }

}


