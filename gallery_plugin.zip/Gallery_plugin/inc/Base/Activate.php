<?php
/**
 * @package  GalleryPlugin
 */

namespace Inc\Base;

class Activate
{
    public static function activate(){
        flush_rewrite_rules();

        $default = array();

        if (!get_option('gallery_plugin')){
            update_option('gallery_plugin',$default);
        }

        $options = get_option('addGallery_settings') ?: array();

        foreach ($options as $option) {
            if (!get_option($option['gallery_title'].'gallery_global_settings')) {
                update_option($option['gallery_title'].'gallery_global_settings', $default);
            }
        }

        if (!get_option('widgetsgallery_global_settings')) {
            update_option($option['gallery_title'].'gallery_global_settings', $default);
        }

        if (!get_option('addGallery_settings')){
            update_option('addGallery_settings',$default);
        }

        if (!get_option('beautifulGalleries_settings')){
            update_option('beautifulGalleries_settings',$default);
        }

        if (!get_option('js_settings')){
            update_option('js_settings',$default);
        }

    }
}