<?php
/**
 * @package  GalleryPlugin
 */

namespace Inc\Base;

use Inc\Api\SettingsApi;
use Inc\Api\Callbacks\AdminCallbacks;
use Inc\Api\Callbacks\GlobalSettingsCallbacks;

class GlobalSettingsController extends BaseController
{

    public $settings;
    public $edit_post;
    public $callbacks;
    public $option_name;
    public $custom_post_types;
    public $globalSettings_callbacks;
    public $subpages = array();

    public function register(){

        if (!$this->activated('global_settings')) return;

        $this->settings = new SettingsApi();
        $this->callbacks = new AdminCallbacks();
        $this->globalSettings_callbacks = new GlobalSettingsCallbacks();

        $this->setSubPages();
        $this->setSettings();
        $this->setSections();
        $this->setFields();

        $this->settings->addSubPages($this->subpages)->withSubPage()->register();

    }

    public function setSubPages(){

        $this->subpages = array(

            array(
                'parent_slug' => 'gallery_plugin',
                'page_title' => 'Global Settings',
                'menu_title' => 'Global Settings',
                'capability' => 'manage_options',
                'menu_slug' => 'gallery_global_settings',
                'callback' => array($this->callbacks,"adminGlobalSettings"),
            ),

        );

    }

    public function setSettings(){

        session_start();

        $this->edit_post = $_POST['edit_post'] ? $_POST['edit_post'] : '';
        $_SESSION['edit_post'] = !empty($this->edit_post) ? $this->edit_post : $_SESSION['edit_post'];
        $this->edit_post = $_SESSION['edit_post'];

            $args = array(

                $args[] = array(
                    'option_group' => 'gallery_plugin_globalSettings_settings',
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'callback' => array( $this->globalSettings_callbacks,'globalSettingsSanitize')
                )

            );

        $this->settings->setSettings($args);

    }

    public function setSections(){

        $args = array(
            array(
                'id' => 'gallery_global_settings_index',
                'title' => 'Gallery Global Settings',
                'callback' => array( $this->globalSettings_callbacks,'globalSettingsSectionManager'),
                'page' => 'gallery_global_settings'
            )
        );

        $this->settings->setSections($args);

    }

    public function setFields(){

        $args = array(

            array(
                'id' => 'image_width',
                'title' => 'Image Width (px)',
                'callback' => array( $this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_width',
                    'placeholder' => 'Width',
                )
            ),
            array(
                'id' => 'image_height',
                'title' => 'Image Height (px)',
                'callback' => array( $this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_height',
                    'placeholder' => 'Height',
                )
            ),
            array(
                'id' => 'image_container_width',
                'title' => 'Image Container Width (%)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_container_width',
                    'placeholder' => 'Container Width',
                )
            ),
            array(
                'id' => 'image_columns',
                'title' => 'Number of image columns',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_columns',
                    'placeholder' => 'Image Columns',
                )
            ),
            array(
                'id' => 'images_per_page',
                'title' => 'Images per gallery',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'images_per_page',
                    'placeholder' => 'Images Per Gallery',
                )
            ),
            array(
                'id' => 'margin_bottom',
                'title' => 'Margin-Bottom',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'margin_bottom',
                    'placeholder' => 'Margin-Bottom',
                )
            ),
            array(
                'id' => 'margin_top',
                'title' => 'Margin-Top',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'margin_top',
                    'placeholder' => 'Margin-Top',
                )
            ),
            array(
                'id' => 'image_padding',
                'title' => 'Image Padding',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_padding',
                    'placeholder' => 'Image Padding',
                )
            ),
            array(
                'id' => 'image_opacity',
                'title' => 'Image Opacity',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_opacity',
                    'placeholder' => 'Image Opacity',
                )
            ),
            array(
                'id' => 'image_z-index',
                'title' => 'Image Z-index',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_z-index',
                    'placeholder' => 'Image Z-index',
                )
            ),
            array(
                'id' => 'border_size_width_border',
                'title' => 'Border Width (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_width_border',
                    'placeholder' => 'Border Width',
                )
            ),
            array(
                'id' => 'border_size_radius_border',
                'title' => 'Border Radius (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_radius_border',
                    'placeholder' => 'Border Radius',
                )
            ),
            array(
                'id' => 'image_filter_invert',
                'title' => 'Image Filter Invert (%)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter_invert',
                    'placeholder' => 'Invert',
                )
            ),
            array(
                'id' => 'image_filter_sepia',
                'title' => 'Image Filter Sepia (%)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter_sepia',
                    'placeholder' => 'Sepia',
                )
            ),
            array(
                'id' => 'image_filter_saturate',
                'title' => 'Image Filter Saturate (%)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter_saturate',
                    'placeholder' => 'Saturate',
                )
            ),
            array(
                'id' => 'image_filter_hue-rotate',
                'title' => 'Image Filter Hue-rotate (deg)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter_hue-rotate',
                    'placeholder' => 'Hue-rotate',
                )
            ),
            array(
                'id' => 'image_filter_brightness',
                'title' => 'Image Filter Brightness (%)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter_brightness',
                    'placeholder' => 'Brightness',
                )
            ),
            array(
                'id' => 'image_filter_contrast',
                'title' => 'Image Filter Contrast (%)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter_contrast',
                    'placeholder' => 'Contrast',
                )
            ),
            array(
                'id' => 'image_transform_translate_x',
                'title' => 'Image Translate X (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_translate_x',
                    'placeholder' => 'Translate X',
                )
            ),
            array(
                'id' => 'image_transform_translate_y',
                'title' => 'Image Translate Y (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_translate_y',
                    'placeholder' => 'Translate Y',
                )
            ),
            array(
                'id' => 'image_transform_scale_x',
                'title' => 'Image Scale X',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_scale_x',
                    'placeholder' => 'Scale X',
                )
            ),
            array(
                'id' => 'image_transform_scale_y',
                'title' => 'Image Scale Y',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_scale_y',
                    'placeholder' => 'Scale Y',
                )
            ),
            array(
                'id' => 'image_transform_skew_x',
                'title' => 'Image Skew X (deg)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_skew_x',
                    'placeholder' => 'Skew X',
                )
            ),
            array(
                'id' => 'image_transform_skew_y',
                'title' => 'Image Skew Y (deg)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_skew_y',
                    'placeholder' => 'Skew Y',
                )
            ),
            array(
                'id' => 'image_transform_rotate',
                'title' => 'Image Rotate (deg)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_rotate',
                    'placeholder' => 'Rotate',
                )
            ),
            array(
                'id' => 'image_box_shadow_x',
                'title' => 'Box Shadow X (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_box_shadow_x',
                    'placeholder' => 'Box Shadow X',
                )
            ),
            array(
                'id' => 'image_box_shadow_y',
                'title' => 'Box Shadow Y (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_box_shadow_y',
                    'placeholder' => 'Box Shadow Y',
                )
            ),
            array(
                'id' => 'image_box_shadow_blur',
                'title' => 'Box Shadow Blur (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_box_shadow_blur',
                    'placeholder' => 'Box Shadow Blur',
                )
            ),
            array(
                'id' => 'image_box_shadow_spread',
                'title' => 'Box Shadow Spread (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_box_shadow_spread',
                    'placeholder' => 'Box Shadow Spread',
                )
            ),
            array(
                'id' => 'image_align',
                'title' => 'Image Align',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_align',
                    'placeholder' => 'Image Align',
                )
            ),
            array(
                'id' => 'write_href',
                'title' => 'Write your Href',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'write_href',
                    'placeholder' => 'href',
                )
            ),
            array(
                'id' => 'write_class',
                'title' => 'Write your class',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'write_class',
                    'placeholder' => 'class',
                )
            ),
            array(
                'id' => 'write_bg_color',
                'title' => 'Write your Background Color',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'write_bg_color',
                    'placeholder' => 'Background Color',
                )
            ),
            array(
                'id' => 'border_size_bg_color',
                'title' => 'Border Color',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_bg_color',
                    'placeholder' => 'Border Color',
                )
            ),
            array(
                'id' => 'border_size_border_size-top',
                'title' => 'Border Size Top',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_border_size-top',
                    'placeholder' => 'Border Size Top',
                )
            ),
            array(
                'id' => 'border_size_border_size-left',
                'title' => 'Border Size Left',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_border_size-left',
                    'placeholder' => 'Border Size',
                )
            ),
            array(
                'id' => 'border_size_border_size-right',
                'title' => 'Border Size Right',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_border_size-right',
                    'placeholder' => 'Border Size Right',
                )
            ),
            array(
                'id' => 'border_size_border_size-bottom',
                'title' => 'Border Size Bottom',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_border_size-bottom',
                    'placeholder' => 'Border Size Bottom',
                )
            ),
            array(
                'id' => 'image_box_shadow_bg_color',
                'title' => 'Box Shadow Color',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_box_shadow_bg_color',
                    'placeholder' => 'Box Shadow Color',
                )
            ),
            array(
                'id' => 'border_size',
                'title' => 'Enable Border Size',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'image_filter',
                'title' => 'Enable Image Filters',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'image_transform',
                'title' => 'Enable Image Transform',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'image_box_shadow',
                'title' => 'Enable Image Box Shadow',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_box_shadow',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'href',
                'title' => 'Enable href attribute',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'href',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'class',
                'title' => 'Enable class attribute',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'class',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'bg_color',
                'title' => 'Enable Background Color',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'bg_color',
                    'class' => 'ui-toggle'
                    )
                ),
            array(
                'id' => 'img_style_generator',
                'title' => 'Enable Img Style Generator',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'img_style_generator',
                    'class' => 'ui-toggle'
                )
            ),

            //hovers

            array(
                'id' => 'image_width_hover',
                'title' => 'Image Width hover (px)',
                'callback' => array( $this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_width_hover',
                    'placeholder' => 'Width hover',
                )
            ),
            array(
                'id' => 'image_height_hover',
                'title' => 'Image Height hover (px)',
                'callback' => array( $this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_height_hover',
                    'placeholder' => 'Height hover',
                )
            ),
            array(
                'id' => 'image_container_width_hover',
                'title' => 'Image Container Width hover (%)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_container_width_hover',
                    'placeholder' => 'Container Width hover',
                )
            ),
            array(
                'id' => 'margin_bottom_hover',
                'title' => 'Margin-Bottom hover',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'margin_bottom_hover',
                    'placeholder' => 'Margin-Bottom hover',
                )
            ),
            array(
                'id' => 'margin_top_hover',
                'title' => 'Margin-Top hover',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'margin_top_hover',
                    'placeholder' => 'Margin-Top hover',
                )
            ),
            array(
                'id' => 'image_padding_hover',
                'title' => 'Image Padding hover',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_padding_hover',
                    'placeholder' => 'Image Padding hover',
                )
            ),
            array(
                'id' => 'image_opacity_hover',
                'title' => 'Image Opacity hover',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_opacity_hover',
                    'placeholder' => 'Image Opacity hover',
                )
            ),
            array(
                'id' => 'border_size_width_border_hover',
                'title' => 'Border Width hover (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_width_border_hover',
                    'placeholder' => 'Border Width hover',
                )
            ),
            array(
                'id' => 'border_size_radius_border_hover',
                'title' => 'Border Radius hover(px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_radius_border_hover',
                    'placeholder' => 'Border Radius hover',
                )
            ),
            array(
                'id' => 'image_filter_invert_hover',
                'title' => 'Image Filter Invert hover (%)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter_invert_hover',
                    'placeholder' => 'Invert hover',
                )
            ),
            array(
                'id' => 'image_filter_sepia_hover',
                'title' => 'Image Filter Sepia hover(%)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter_sepia_hover',
                    'placeholder' => 'Sepia hover',
                )
            ),
            array(
                'id' => 'image_filter_saturate_hover',
                'title' => 'Image Filter Saturate hover (%)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter_saturate_hover',
                    'placeholder' => 'Saturate hover',
                )
            ),
            array(
                'id' => 'image_filter_hue-rotate_hover',
                'title' => 'Image Filter Hue-rotate hover (deg)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter_hue-rotate_hover',
                    'placeholder' => 'Hue-rotate hover',
                )
            ),
            array(
                'id' => 'image_filter_brightness_hover',
                'title' => 'Image Filter Brightness hover (%)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter_brightness_hover',
                    'placeholder' => 'Brightness hover',
                )
            ),
            array(
                'id' => 'image_filter_contrast_hover',
                'title' => 'Image Filter Contrast hover (%)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter_contrast_hover',
                    'placeholder' => 'Contrast hover',
                )
            ),
            array(
                'id' => 'image_transform_translate_x_hover',
                'title' => 'Image Translate X hover (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_translate_x_hover',
                    'placeholder' => 'Translate X hover',
                )
            ),
            array(
                'id' => 'image_transform_translate_y_hover',
                'title' => 'Image Translate Y hover (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_translate_y_hover',
                    'placeholder' => 'Translate Y hover',
                )
            ),
            array(
                'id' => 'image_transform_scale_x_hover',
                'title' => 'Image Scale X hover',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_scale_x_hover',
                    'placeholder' => 'Scale X hover',
                )
            ),
            array(
                'id' => 'image_transform_scale_y_hover',
                'title' => 'Image Scale Y hover',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_scale_y_hover',
                    'placeholder' => 'Scale Y hover',
                )
            ),
            array(
                'id' => 'image_transform_skew_x_hover',
                'title' => 'Image Skew X hover (deg)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_skew_x_hover',
                    'placeholder' => 'Skew X hover',
                )
            ),
            array(
                'id' => 'image_transform_skew_y_hover',
                'title' => 'Image Skew Y hover (deg)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_skew_y_hover',
                    'placeholder' => 'Skew Y hover',
                )
            ),
            array(
                'id' => 'image_transform_rotate_hover',
                'title' => 'Image Rotate hover (deg)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_rotate_hover',
                    'placeholder' => 'Rotate hover',
                )
            ),
            array(
                'id' => 'image_box_shadow_x_hover',
                'title' => 'Box Shadow X hover (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_box_shadow_x_hover',
                    'placeholder' => 'Box Shadow X hover',
                )
            ),
            array(
                'id' => 'image_box_shadow_y_hover',
                'title' => 'Box Shadow Y hover (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_box_shadow_y_hover',
                    'placeholder' => 'Box Shadow Y hover',
                )
            ),
            array(
                'id' => 'image_box_shadow_blur_hover',
                'title' => 'Box Shadow Blur hover (px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_box_shadow_blur_hover',
                    'placeholder' => 'Box Shadow Blur hover',
                )
            ),
            array(
                'id' => 'image_box_shadow_spread_hover',
                'title' => 'Box Shadow Spread hover(px)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_box_shadow_spread_hover',
                    'placeholder' => 'Box Shadow Spread hover',
                )
            ),

            array(
                'id' => 'image_align_hover',
                'title' => 'Image Align hover',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_align_hover',
                    'placeholder' => 'Image Align hover',
                )
            ),
            array(
                'id' => 'write_bg_color_hover',
                'title' => 'Background Color hover',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'write_bg_color_hover',
                    'placeholder' => 'Background Color hover',
                )
            ),
            array(
                'id' => 'border_size_bg_color_hover',
                'title' => 'Border Color hover',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_bg_color_hover',
                    'placeholder' => 'Border Color hover',
                )
            ),
            array(
                'id' => 'border_size_border_size-top_hover',
                'title' => 'Border Size Top Hover',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_border_size-top_hover',
                    'placeholder' => 'Border Size Top Hover',
                )
            ),
            array(
                'id' => 'border_size_border_size-left_hover',
                'title' => 'Border Size Left Hover',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_border_size-left_hover',
                    'placeholder' => 'Border Size Left Hover',
                )
            ),
            array(
                'id' => 'border_size_border_size-right_hover',
                'title' => 'Border Size Right Hover',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_border_size-right_hover',
                    'placeholder' => 'Border Size Right Hover',
                )
            ),
            array(
                'id' => 'border_size_border_size-bottom_hover',
                'title' => 'Border Size Bottom Hover',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_border_size-bottom_hover',
                    'placeholder' => 'Border Size Bottom Hover',
                )
            ),
            array(
                'id' => 'image_box_shadow_bg_color_hover',
                'title' => 'Box Shadow Color hover',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_box_shadow_bg_color_hover',
                    'placeholder' => 'Box Shadow Color hover',
                )
            ),
            array(
                'id' => 'border_size_hover',
                'title' => 'Enable Border Size hover',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'border_size_hover',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'image_filter_hover',
                'title' => 'Enable Image Filters hover',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_filter_hover',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'image_transform_hover',
                'title' => 'Enable Image Transform hover',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_transform_hover',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'image_box_shadow_hover',
                'title' => 'Enable Image Box Shadow hover',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'image_box_shadow_hover',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'bg_color_hover',
                'title' => 'Enable Background Color hover',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'bg_color_hover',
                    'class' => 'ui-toggle'
                )
            ),
            array(
                'id' => 'active_hover',
                'title' => '',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'active_hover',
                    'class' => 'active'
                )
            ),
            array(
                'id' => 'img_style_generator_hover',
                'title' => 'Enable Img Hover Style Generator',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'img_style_generator_hover',
                    'class' => 'ui-toggle'
                )
            ),

            //animations

            array(
                'id' => 'slide_effects_animation',
                'title' => 'Slide Effects',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'slide_effects_animation',
                    'placeholder' => 'Slide Effects',
                )
            ),
            array(
                'id' => 'fade_effects_animation',
                'title' => 'Fade Effects',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'fade_effects_animation',
                    'placeholder' => 'Fade Effects',
                )
            ),
            array(
                'id' => 'zoom_effects_animation',
                'title' => 'Zoom Effects',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'zoom_effects_animation',
                    'placeholder' => 'Zoom Effects',
                )
            ),
            array(
                'id' => 'bounce_effects_animation',
                'title' => 'Bounce Effects',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'bounce_effects_animation',
                    'placeholder' => 'Bounce Effects',
                )
            ),
            array(
                'id' => 'flip_effects_animation',
                'title' => 'Flip Effects',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'flip_effects_animation',
                    'placeholder' => 'Flip Effects',
                )
            ),
            array(
                'id' => 'rotate_effects_animation',
                'title' => 'Rotate Effects',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'rotate_effects_animation',
                    'placeholder' => 'Rotate Effects',
                )
            ),
            array(
                'id' => 'other_effects_animation',
                'title' => 'Other Effects',
                'callback' => array($this->globalSettings_callbacks,'textField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'other_effects_animation',
                    'placeholder' => 'Other Effects',
                )
            ),
            array(
                'id' => 'duration_animation',
                'title' => 'Animation duration (ms)',
                'callback' => array($this->globalSettings_callbacks,'numberField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'duration_animation',
                    'placeholder' => 'Animation duration',
                )
            ),
            array(
                'id' => 'active_animation',
                'title' => '',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'active_animation',
                    'class' => 'active'
                )
            ),
            array(
                'id' => 'img_style_generator_animation',
                'title' => 'Enable Img Animate Style Generator',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'img_style_generator_animation',
                    'class' => 'ui-toggle'
                )
            ),

            //custom css

            array(
                'id' => 'custom_css',
                'title' => 'Custom Css',
                'callback' => array($this->globalSettings_callbacks,'textArea'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'custom_css',
                    'placeholder' => 'Custom Css',
                )
            ),
            array(
                'id' => 'active_custom_css',
                'title' => '',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'active_custom_css',
                    'class' => 'active'
                )
            ),
            array(
                'id' => 'img_style_generator_custom_css',
                'title' => 'Enable Img Custom Css Style Generator',
                'callback' => array($this->globalSettings_callbacks,'checkboxField'),
                'page' => 'gallery_global_settings',
                'section' => 'gallery_global_settings_index',
                'args' => array(
                    'option_name' =>  $this->edit_post.'gallery_global_settings',
                    'label_for' => 'img_style_generator_custom_css',
                    'class' => 'ui-toggle'
                )
            ),
        );

        $this->settings->setFields($args);

    }

}
