<?php
/**
 * @package  GalleryPlugin
 */

namespace Inc\Base;

use Inc\Api\SettingsApi;
use Inc\Api\Callbacks\AdminCallbacks;

class ShortCodeController extends BaseController
{

    public $subpages = array();
    public $callbacks;
    public $options;
    public $shortcode;
    public $settings;

    public function register(){

        if (!$this->activated('shortcode_manager')) return;

        $this->settings = new SettingsApi();
        $this->callbacks = new AdminCallbacks();

        $this->setSubPages();
        $this->settings->addSubPages($this->subpages)->register();

        $this->options = get_option('addGallery_settings') ? get_option('addGallery_settings') : array();

        foreach ($this->options as $option){
            $gallery_title = $option['gallery_title'];
            add_shortcode($gallery_title, array($this, 'gallery_shortcode'));
        }

    }

    public function gallery_shortcode(){

        ob_start();

        include $this->plugin_path."templates/gallery.php";

        return ob_get_clean();

    }

    public function setSubPages(){

        $this->subpages = array(

            array(
                'parent_slug' => 'gallery_plugin',
                'page_title' => 'Shortcode',
                'menu_title' => 'Shortcode Manager',
                'capability' => 'manage_options',
                'menu_slug' => 'gallery_shortcode',
                'callback' => array($this->callbacks,"adminShortcode"),
            ),

        );

    }

}
