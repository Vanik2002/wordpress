<?php
/**
 * @package  GalleryPlugin
 */

namespace Inc\Base;

use Inc\Api\SettingsApi;
use Inc\Api\Callbacks\AdminCallbacks;
use Inc\Api\Callbacks\AddGalleryCallbacks;

class AddGalleryController extends BaseController
{

    public $settings;
    public $callbacks;
    public $custom_post_types;
    public $addGallery_callbacks;
    public $subpages = array();

    public function register(){

        if (!$this->activated('addGallery_manager')) return;

        $this->settings = new SettingsApi();
        $this->callbacks = new AdminCallbacks();
        $this->addGallery_callbacks = new AddGalleryCallbacks();

        $this->setSubPages();
        $this->setSettings();
        $this->setSections();
        $this->setFields();

        $this->settings->addSubPages($this->subpages)->withSubPage()->register();

    }


    public function setSubPages(){

        $this->subpages = array(

            array(
                'parent_slug' => 'gallery_plugin',
                'page_title' => 'Add Gallery',
                'menu_title' => 'Add Gallery',
                'capability' => 'manage_options',
                'menu_slug' => 'addGallery_settings',
                'callback' => array($this->callbacks, "adminAddGallery"),
            ),

        );

    }

    public function setSettings(){

        $args = array(

            $args[] = array(
                'option_group' => 'gallery_plugin_addGallery_settings',
                'option_name' => 'addGallery_settings',
                'callback' => array($this->addGallery_callbacks, 'AddGallerySanitize')
            )

        );

        $this->settings->setSettings($args);

    }

    public function setSections(){

        $args = array(

            array(
                'id' => 'addGallery_index',
                'title' => 'Add Gallery',
                'callback' => array($this->addGallery_callbacks, 'AddGallerySectionManager'),
                'page' => 'addGallery_settings'
            )

        );

        $this->settings->setSections($args);
    }


    public function setFields(){

        $args = array(

            array(
                'id' => 'gallery_title',
                'title' => 'Gallery title',
                'callback' => array($this->addGallery_callbacks, 'textField'),
                'page' => 'addGallery_settings',
                'section' => 'addGallery_index',
                'args' => array(
                    'option_name' => 'addGallery_settings',
                    'label_for' => 'gallery_title',
                    'placeholder' => 'add Gallery',
                )
            ),

        );

        $options = get_option('addGallery_settings');

        foreach ($options as $option) {
            $arr = array(
                'id' => $option['gallery_title'],
                'title' => '',
                'callback' => array($this->addGallery_callbacks, 'textField'),
                'page' => 'addGallery_settings',
                'section' => 'addGallery_index',
                'args' => array(
                    'option_name' => 'addGallery_settings',
                    'label_for' => $option['gallery_title'],
                    'placeholder' => 'Add Image',
                )
            );

            array_push($args, $arr);
        }

        $this->settings->setFields($args);

    }

}