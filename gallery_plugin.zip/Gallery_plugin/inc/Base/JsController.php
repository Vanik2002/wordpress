<?php
/**
 * @package  GalleryPlugin
 */

namespace Inc\Base;

use Inc\Api\SettingsApi;
use Inc\Api\Callbacks\AdminCallbacks;
use Inc\Api\Callbacks\jsCallbacks;

class JsController extends BaseController
{

    public $settings;
    public $callbacks;
    public $custom_post_types;
    public $js_callbacks;
    public $subpages = array();

    public function register(){

        if (!$this->activated('js_settings')) return;

        $this->settings = new SettingsApi();
        $this->callbacks = new AdminCallbacks();
        $this->js_callbacks = new JsCallbacks();

        $this->setSubPages();
        $this->setSettings();
        $this->setSections();
        $this->setFields();

        $this->settings->addSubPages($this->subpages)->withSubPage()->register();

    }

    public function setSubPages(){

        $this->subpages = array(

            array(
                'parent_slug' => 'gallery_plugin',
                'page_title' => 'JS Code Editor',
                'menu_title' => 'JS Code Editor',
                'capability' => 'manage_options',
                'menu_slug' => 'js_settings',
                'callback' => array($this->callbacks,"adminJs"),
            ),

        );

    }

    public function setSettings(){

        $args = array(

            $args[] = array(
                'option_group' => 'gallery_plugin_js_settings',
                'option_name' => 'js_settings',
                'callback' => array( $this->js_callbacks,'JsSanitize')
            )

        );

        $this->settings->setSettings($args);

    }

    public function setSections(){

        $args = array(
            array(
                'id' => 'js_settings_index',
                'title' => 'JS Code Editor',
                'callback' => array( $this->js_callbacks,'JsSectionManager'),
                'page' => 'js_settings'
            )
        );

        $this->settings->setSections($args);

    }

    public function setFields(){

        $args = array(
            
            array(
                'id' => 'custom_Js',
                'title' => 'Custom JS',
                'callback' => array($this->js_callbacks,'textArea'),
                'page' => 'js_settings',
                'section' => 'js_settings_index',
                'args' => array(
                    'option_name' => 'js_settings',
                    'label_for' => 'custom_Js',
                    'placeholder' => 'Custom JS',
                )
            ),
            
        );

        $this->settings->setFields($args);

    }

}
