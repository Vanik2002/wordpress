<?php
/**
 * @package  GalleryPlugin
 */

namespace Inc\Base;

use Inc\Api\Widgets\MediaWidget;

class WidgetController extends BaseController
{

    public $settings;
    public $callbacks;
    public $subpages = array();
    public $taxonomies = array();

    public function register(){

        if (!$this->activated('media_widget')) return;

        $media_widget = new MediaWidget();
        $media_widget->register();

    }

}
