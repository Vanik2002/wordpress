<?php
/**
 * @package  GalleryPlugin
 */

namespace Inc\Pages;


use Inc\Api\SettingsApi;
use Inc\Base\BaseController;
use Inc\Api\Callbacks\AdminCallbacks;
use Inc\Api\Callbacks\ManagerCallbacks;

class Dashboard extends BaseController
{

    public $settings;
    public $callbacks;
    public $callbacks_manager;

    public $pages = array();

    public function register(){

        $this->settings = new SettingsApi();
        $this->callbacks = new AdminCallbacks();
        $this->callbacks_manager = new ManagerCallbacks();

        $this->setPages();
        $this->setSettings();
        $this->setSections();
        $this->setFields();

        $this->settings->addPages($this->pages)->register();

    }

    public function setPages(){

        $this->pages = [

            [
                'page_title' => 'Gallery Plugin',
                'menu_title' => 'Gallery Settings',
                'capability' => 'manage_options',
                'menu_slug' => 'gallery_plugin',
                'callback' => array($this->callbacks,"adminDashboard"),
                'icon_url' => 'dashicons-format-gallery',
                'position' => '110'
            ],

        ];

    }



    public function setSettings(){

        $args = array(

            $args[] = array(
                'option_group' => 'gallery_plugin_settings',
                'option_name' => 'gallery_plugin',
                'callback' => array($this->callbacks_manager,'checkboxSanitize')
            )

        );

        $this->settings->setSettings($args);

    }

    public function setSections(){

        $args = array(

            array(
                'id' => 'gallery_admin_index',
                'title' => 'Settings Manager',
                'callback' => array($this->callbacks_manager,'AdminSectionManager'),
                'page' => 'gallery_plugin'
            )

        );

        $this->settings->setSections($args);

    }

    public function setFields(){

        $args = array();

        foreach ($this->managers as $key => $value){

            $args[] =  array(

                'id' => $key,
                'title' => $value,
                'callback' => array($this->callbacks_manager,'checkboxField'),
                'page' => 'gallery_plugin',
                'section' => 'gallery_admin_index',
                'args' => array(
                    'option_name' => 'gallery_plugin',
                    'label_for' => $key,
                    'class' => 'ui-toggle'
                )
            );

        }

        $this->settings->setFields($args);

    }

}