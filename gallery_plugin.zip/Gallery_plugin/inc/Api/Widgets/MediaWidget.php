<?php
/**
 * @package  GalleryPlugin
 */

namespace Inc\Api\Widgets;

use WP_Widget;

class MediaWidget extends WP_Widget
{

    public $widget_ID;
    public $widget_name;
    public $plugin_path;
    public $widget_options = array();
    public $control_options = array();

    public function __construct(){

        $this->widget_ID = 'gallery_media_widget';
        $this->widget_name = 'Gallery Media Widget';

        $this->widget_options = array(
            'classname' => $this->widget_ID,
            'description' => $this->widget_name,
            'customize_selective_refresh' => true,
        );

        $this->control_options = array(
            'width' => 150,
            'height' => 150
        );

        $this->plugin_path = plugin_dir_path(dirname(__FILE__,2));

    }

    public function register(){

        parent::__construct($this->widget_ID,$this->widget_name,$this->widget_options,$this->control_options);

        add_action('widgets_init',array($this,'widgetInit'));

    }

    public function widgetInit(){
        register_widget($this);
    }

    public function widget($args,$instance){

        $href = '';
        $class = '';
        $float = '';
        $margin_top = "";
        $image_index = '';
        $image_width = '';
        $image_height = '';
        $effect_class = '';
        $effects = array();
        $image_padding = '';
        $image_opacity = '';
        $image_columns = '';
        $margin_bottom = '';
        $image_container_width = '';
        $beautiful_gallery_value = '';

        include "$this->plugin_path/../templates/global_settings/globalSettingsValues.php";

        $beautiful_gallery_options = get_option('beautifulGalleries_settings') ? get_option('beautifulGalleries_settings') : array();

        foreach ($effects as $effect => $value){

            $effect_name = str_replace('effects_animation','',$effect);
            $effect_animation = str_replace($effect_name,'',$effect);

            if ($effect_animation == 'effects_animation' && $value !== ''){
                $effect_class = $value;
            }

        }

        foreach ($beautiful_gallery_options as $option){
            $beautiful_gallery_value = $option;
        }

        echo $args['before_widget'];

        $image_src_array = explode(',',$instance['image']);

        if (!empty($instance['image']) && !empty($beautiful_gallery_value['widgets'])){
            include "$this->plugin_path/../templates/beautiful_galleries/beautiful_gallery_style.php";
            include "$this->plugin_path/../templates/beautiful_galleries/beautiful_gallery_widgets_front.php";
        }
        else if (!empty($instance['image']) && empty($beautiful_gallery_value['widgets'])) {

            echo '
                  <div class="e-gallery-container gallery_container background-color" style="width: ' . $image_container_width . ';display: flex; flex-wrap: wrap; justify-content: flex-start;margin: auto; z-index: '.$image_index.'">
            ';
                    foreach ($image_src_array as $image_src){
                        echo
                            '<div class="gallery_image_container ' . $effect_class . '" style="width: ' . $image_columns . ';margin-top: ' . $margin_top . '; margin-bottom: ' . $margin_bottom . ';padding: 20px;text-align: center;">
                                <a href="' . $href . '"><img src="' . esc_url($image_src) . '" alt="" width="' . $image_width . '" height="' . $image_height . '" class="' . $class . '"  style="float: ' . $float . ';padding: ' . $image_padding . ';opacity: ' . $image_opacity . ';"></a>
                             </div>
                        ';
                    }

            echo '</div>';

        }

        echo $args['after_widget'];

    }

    public function form($instance){

        $image = !empty($instance['image']) ? $instance['image'] : '';
        $imageID = esc_attr($this->get_field_id('image'));
        $image_src_array = explode(',',$instance['image']);

        ?>
            <div>
                <label>
                    <input type="checkbox" class="widget_checkbox_update">
                </label>
                <div>
                    <label for="<?= $imageID; ?>"></label><input type="text" class="wide_fat image-upload" id="<?= $imageID; ?>" name="<?php echo esc_attr($this->get_field_name('image'));?>" value="<?= esc_url($image); ?>">
                    <buttom type="button" class="glowing-btn js-image-upload"><span class="glowing-txt">U<span class="faulty-letter">P</span>LOAD</span></buttom>
                </div>
            </div>
        <?php

          echo '
                <div class="row">';

                    if (!empty($instance['image'])) {
                        foreach ($image_src_array as $image_src){
                            echo ' 
                                 <div class="column">
                                    <div class="column_delete">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z"/></svg>
                                    </div>
                                    <img src="'.$image_src.'" alt="Add Gallery" ">
                                </div>
                            ';
                        }
                    }

          echo '</div>';

    }

    public function update($new_instance,$old_instance){

        $instance = $old_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);
        $instance['image'] = !empty($new_instance['image']) ? $new_instance['image'] : '';

        return $instance;

    }

}
