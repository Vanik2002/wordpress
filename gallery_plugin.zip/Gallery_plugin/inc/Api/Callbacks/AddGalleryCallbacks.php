<?php

/**
 * @package  GalleryPlugin
 */

namespace Inc\Api\Callbacks;

class AddGalleryCallbacks
{

    public function AddGallerySectionManager(){

        echo "<h4>Add Your Gallery</h4>";

    }

    public function AddGallerySanitize($input){

        $output = get_option('addGallery_settings');

        if (isset($_POST['remove'])){
            unset($output[$_POST['remove']]);
            return $output;
        }

        if (count($output) === 0){
            $output[$input['gallery_title']] = $input;
            return $output;
        }

        foreach ($output as $key => $value){

            if ($input['gallery_title'] === $key){
                $output[$key] = $input;
            }
            else{
                $output[$input['gallery_title']] = $input;
            }
        }
        return $output;

    }

    public function textField($args){

        $value = '';
        $name = $args['label_for'];
        $placeholder = $args['placeholder'];
        $option_name = $args['option_name'];
        $input = get_option($option_name) ? get_option($option_name) : array();
        $class = $name == 'gallery_title' ? 'gallery_title_class_display' : '';

        foreach ($input as $key){
            $value = $key;
        }

        if ($value !== ''){
            $value= $value[$name];
        }

        if (isset($_POST["edit_post"])){
            $value = $input[$_POST['edit_post']][$name];
        }

        $images_src = explode(",",$value);

        if ($name !== 'gallery_title' &&  isset($_POST["edit_post"])  && $name == $input[$_POST['edit_post']]['gallery_title']){

            echo '
                <div>
                    <input type="text" id="' . $name . '" name="' . $option_name . '['.$name.']" value="' . $value . '" class="regular-text add_image add_image_class_display" placeholder="'.$placeholder.'" disabled>
                    <button class="glowing-btn upload add_image_class_display"><span class="glowing-txt">U<span class="faulty-letter">P</span>LOAD</span></button>
                  </div>
                  
                  <div class="gallery_container add_image_class_display">
                     <div style="text-align:center">
                        <h2 class="black-lives-matter">Image Gallery</h2>
                    </div>
                    <div class="row">
            ';
                        foreach ($images_src as $image_src){

                            echo '   
                                <div class="column">
                                    <div class="column_delete">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M256 80c0-17.7-14.3-32-32-32s-32 14.3-32 32V224H48c-17.7 0-32 14.3-32 32s14.3 32 32 32H192V432c0 17.7 14.3 32 32 32s32-14.3 32-32V288H400c17.7 0 32-14.3 32-32s-14.3-32-32-32H256V80z"/></svg>
                                    </div>
                                    <img src="'.$image_src.'" alt="Add Gallery" ">
                                </div> 
                            ';

                        }

            echo   '</div>
                </div>';
        }

        else if($name === 'gallery_title'){
            echo '
                <input type="text" id="' . $name . '" name="' . $option_name . '['.$name.']" value="'.$value.'" class="regular-text '.$class.'" placeholder="'.$placeholder.'" required>
            ';
        }

    }

    public function checkboxField($args){

        $checked = false;
        $classes = $args['class'];
        $name = $args['label_for'];
        $option_name = $args['option_name'];

        if (isset($_POST["edit_post"])){
            $checkbox = get_option($option_name);
            $checked = isset($checkbox[$_POST["edit_post"]][$name]) ?: false;
        }

        echo '
              <div class="' . $classes . '">                
                  <input type="checkbox" id="' . $name . '" name="' . $option_name . '['.$name.']" value="1" class="" ' . ( $checked ? 'checked' : '') . '>
                  <label for="' . $name . '" class="toggler-wrapper"></label>             
             </div>
        ';

    }

}