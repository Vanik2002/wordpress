<?php

/**
 * @package  GalleryPlugin
 */

namespace Inc\Api\Callbacks;

class GlobalSettingsCallbacks
{

    public function globalSettingsSectionManager(){

        echo '<h4>Create Global Settings</h4>';

    }

    public function globalSettingsSanitize($input){

        $output = get_option('gallery_global_settings');

        if (isset($_POST['remove'])){
            unset($output[$_POST['remove']]);
            return $output;
        }

        if (count($output) === 0){
            $output[$input['post_type']] = $input;
            return $output;
        }

        foreach ($output as $key => $value){

            if ($input['post_type'] === $key){
                $output[$key] = $input;
            }
            else{
                $output[$input['post_type']] = $input;
            }

        }

        return $output;
    }

    public function textArea($args){

        $value = '';
        $display = '';
        $name = $args['label_for'];
        $option_name = $args['option_name'];
        $input = get_option($option_name) ? get_option($option_name) : unserialize('a:1:{s:0:"";a:81:{s:11:"image_width";s:3:"150";s:12:"image_height";s:3:"150";s:21:"image_container_width";s:3:"100";s:13:"image_columns";s:1:"3";s:15:"images_per_page";s:2:"20";s:13:"margin_bottom";s:1:"0";s:10:"margin_top";s:1:"0";s:13:"image_padding";s:1:"0";s:13:"image_opacity";s:1:"1";s:13:"image_z-index";s:1:"0";s:24:"border_size_width_border";s:1:"0";s:25:"border_size_radius_border";s:1:"0";s:19:"image_filter_invert";s:1:"0";s:18:"image_filter_sepia";s:1:"0";s:21:"image_filter_saturate";s:3:"100";s:23:"image_filter_hue-rotate";s:1:"0";s:23:"image_filter_brightness";s:3:"100";s:21:"image_filter_contrast";s:0:"";s:27:"image_transform_translate_x";s:1:"0";s:27:"image_transform_translate_y";s:1:"0";s:23:"image_transform_scale_x";s:1:"1";s:23:"image_transform_scale_y";s:1:"1";s:22:"image_transform_skew_x";s:1:"0";s:22:"image_transform_skew_y";s:1:"0";s:22:"image_transform_rotate";s:1:"0";s:18:"image_box_shadow_x";s:1:"0";s:18:"image_box_shadow_y";s:1:"0";s:21:"image_box_shadow_blur";s:0:"";s:23:"image_box_shadow_spread";s:1:"0";s:10:"write_href";s:0:"";s:11:"write_class";s:0:"";s:14:"write_bg_color";s:0:"";s:20:"border_size_bg_color";s:0:"";s:27:"border_size_border_size-top";s:0:"";s:28:"border_size_border_size-left";s:0:"";s:29:"border_size_border_size-right";s:0:"";s:30:"border_size_border_size-bottom";s:0:"";s:25:"image_box_shadow_bg_color";s:0:"";s:17:"image_width_hover";s:0:"";s:18:"image_height_hover";s:0:"";s:27:"image_container_width_hover";s:0:"";s:19:"margin_bottom_hover";s:0:"";s:16:"margin_top_hover";s:0:"";s:19:"image_padding_hover";s:0:"";s:19:"image_opacity_hover";s:0:"";s:30:"border_size_width_border_hover";s:0:"";s:31:"border_size_radius_border_hover";s:0:"";s:25:"image_filter_invert_hover";s:0:"";s:24:"image_filter_sepia_hover";s:0:"";s:27:"image_filter_saturate_hover";s:0:"";s:29:"image_filter_hue-rotate_hover";s:0:"";s:29:"image_filter_brightness_hover";s:0:"";s:27:"image_filter_contrast_hover";s:0:"";s:33:"image_transform_translate_x_hover";s:0:"";s:33:"image_transform_translate_y_hover";s:0:"";s:29:"image_transform_scale_x_hover";s:0:"";s:29:"image_transform_scale_y_hover";s:0:"";s:28:"image_transform_skew_x_hover";s:0:"";s:28:"image_transform_skew_y_hover";s:0:"";s:28:"image_transform_rotate_hover";s:0:"";s:24:"image_box_shadow_x_hover";s:0:"";s:24:"image_box_shadow_y_hover";s:0:"";s:27:"image_box_shadow_blur_hover";s:0:"";s:29:"image_box_shadow_spread_hover";s:0:"";s:20:"write_bg_color_hover";s:0:"";s:26:"border_size_bg_color_hover";s:0:"";s:33:"border_size_border_size-top_hover";s:0:"";s:34:"border_size_border_size-left_hover";s:0:"";s:35:"border_size_border_size-right_hover";s:0:"";s:36:"border_size_border_size-bottom_hover";s:0:"";s:31:"image_box_shadow_bg_color_hover";s:0:"";s:23:"slide_effects_animation";s:0:"";s:22:"fade_effects_animation";s:0:"";s:22:"zoom_effects_animation";s:0:"";s:24:"bounce_effects_animation";s:0:"";s:22:"flip_effects_animation";s:0:"";s:24:"rotate_effects_animation";s:0:"";s:23:"other_effects_animation";s:0:"";s:18:"duration_animation";s:4:"1000";s:10:"custom_css";s:0:"";s:29:"global_settings_category_data";s:0:"";}}');

        foreach ($input as $key){
            $value = $key;
        }

        echo '
        <textarea id="' . $name . '" name="' . $option_name . '['.$name.']"  class="customize-control-textarea elementor-control-type-textarea '.$display.'">'.$value[$name].'</textarea>
        ';

    }

    public function textField($args){

        $value = '';
        $display = '';
        $border_class = '';
        $name = $args['label_for'];
        $placeholder = $args['placeholder'];
        $option_name = $args['option_name'];
        $input = get_option($option_name) ? get_option($option_name) : unserialize('a:1:{s:0:"";a:81:{s:11:"image_width";s:3:"150";s:12:"image_height";s:3:"150";s:21:"image_container_width";s:3:"100";s:13:"image_columns";s:1:"3";s:15:"images_per_page";s:2:"20";s:13:"margin_bottom";s:1:"0";s:10:"margin_top";s:1:"0";s:13:"image_padding";s:1:"0";s:13:"image_opacity";s:1:"1";s:13:"image_z-index";s:1:"0";s:24:"border_size_width_border";s:1:"0";s:25:"border_size_radius_border";s:1:"0";s:19:"image_filter_invert";s:1:"0";s:18:"image_filter_sepia";s:1:"0";s:21:"image_filter_saturate";s:3:"100";s:23:"image_filter_hue-rotate";s:1:"0";s:23:"image_filter_brightness";s:3:"100";s:21:"image_filter_contrast";s:0:"";s:27:"image_transform_translate_x";s:1:"0";s:27:"image_transform_translate_y";s:1:"0";s:23:"image_transform_scale_x";s:1:"1";s:23:"image_transform_scale_y";s:1:"1";s:22:"image_transform_skew_x";s:1:"0";s:22:"image_transform_skew_y";s:1:"0";s:22:"image_transform_rotate";s:1:"0";s:18:"image_box_shadow_x";s:1:"0";s:18:"image_box_shadow_y";s:1:"0";s:21:"image_box_shadow_blur";s:0:"";s:23:"image_box_shadow_spread";s:1:"0";s:10:"write_href";s:0:"";s:11:"write_class";s:0:"";s:14:"write_bg_color";s:0:"";s:20:"border_size_bg_color";s:0:"";s:27:"border_size_border_size-top";s:0:"";s:28:"border_size_border_size-left";s:0:"";s:29:"border_size_border_size-right";s:0:"";s:30:"border_size_border_size-bottom";s:0:"";s:25:"image_box_shadow_bg_color";s:0:"";s:17:"image_width_hover";s:0:"";s:18:"image_height_hover";s:0:"";s:27:"image_container_width_hover";s:0:"";s:19:"margin_bottom_hover";s:0:"";s:16:"margin_top_hover";s:0:"";s:19:"image_padding_hover";s:0:"";s:19:"image_opacity_hover";s:0:"";s:30:"border_size_width_border_hover";s:0:"";s:31:"border_size_radius_border_hover";s:0:"";s:25:"image_filter_invert_hover";s:0:"";s:24:"image_filter_sepia_hover";s:0:"";s:27:"image_filter_saturate_hover";s:0:"";s:29:"image_filter_hue-rotate_hover";s:0:"";s:29:"image_filter_brightness_hover";s:0:"";s:27:"image_filter_contrast_hover";s:0:"";s:33:"image_transform_translate_x_hover";s:0:"";s:33:"image_transform_translate_y_hover";s:0:"";s:29:"image_transform_scale_x_hover";s:0:"";s:29:"image_transform_scale_y_hover";s:0:"";s:28:"image_transform_skew_x_hover";s:0:"";s:28:"image_transform_skew_y_hover";s:0:"";s:28:"image_transform_rotate_hover";s:0:"";s:24:"image_box_shadow_x_hover";s:0:"";s:24:"image_box_shadow_y_hover";s:0:"";s:27:"image_box_shadow_blur_hover";s:0:"";s:29:"image_box_shadow_spread_hover";s:0:"";s:20:"write_bg_color_hover";s:0:"";s:26:"border_size_bg_color_hover";s:0:"";s:33:"border_size_border_size-top_hover";s:0:"";s:34:"border_size_border_size-left_hover";s:0:"";s:35:"border_size_border_size-right_hover";s:0:"";s:36:"border_size_border_size-bottom_hover";s:0:"";s:31:"image_box_shadow_bg_color_hover";s:0:"";s:23:"slide_effects_animation";s:0:"";s:22:"fade_effects_animation";s:0:"";s:22:"zoom_effects_animation";s:0:"";s:24:"bounce_effects_animation";s:0:"";s:22:"flip_effects_animation";s:0:"";s:24:"rotate_effects_animation";s:0:"";s:23:"other_effects_animation";s:0:"";s:18:"duration_animation";s:4:"1000";s:10:"custom_css";s:0:"";s:29:"global_settings_category_data";s:0:"";}}');

        foreach ($input as $key){
            $value = $key;
        }

        $write_name = str_replace('write_','',$name);
        $write = str_replace("_$write_name",'',$name);

        $border = str_replace('border_size_','',$name);
        $box_shadow = str_replace('image_box_shadow_','',$name);

        $hover = '';
        $hover_container = str_replace('hover','',$name);
        $hover_class = str_replace($hover_container,'',$name);

        $animation = '';
        $animation_container = str_replace('animation','',$name);
        $animation_class = str_replace($animation_container,'',$name);

        if (!empty($hover_class)){
            $hover = "_$hover_class";
        }

        if (!empty($animation_class)){
            $animation = "_$animation_class";
        }

        $effects =  str_replace("_effects$animation",'',$name);

        if ($name == "border_size_$border"){
            $border_style =  str_replace("_$border",'',$name);
            $display = empty($value["$border_style$hover$animation"])  ? 'display-none-parent' : '';
            $border_class =  'my_border_class';
        }

        if ($name === "image_box_shadow_$box_shadow" ){
            $image_box_shadow = str_replace("_$box_shadow",'',$name);
            $display = empty($value["$image_box_shadow$hover$animation"]) ? 'display-none-parent' : '';
        }

        if ($write == "write"){
            $display = empty($value[$write_name])  && $value[$write_name] !== '' ? 'display-none-parent' : '';
        }

        $disabled = $name == "image_align$hover$animation"  ? 'disabled' : '';

        echo' 
            <input type="text" id="' . $name . '" name="' . $option_name . '['.$name.']" value="'.$value[$name].'" class="regular-text '.$display.' '.$border_class.' '.$hover_class.' '.$animation_class.'" placeholder="'.$placeholder.'" '.$disabled.'>
        ';

        if (strpos($name,'color')){
            echo '
                <label for="' . $name . '"><input type="color" class="my_img_color"></label>
            ';
        }



        if ($name == "border_size_$border" && $border !== 'bg_color' && $border !== 'bg_color_hover'){
            echo '
                         <select class="options">
                            <option value="" disabled="disabled" selected="selected">Border Sizes</option>
                            <option value="solid">solid</option>
                            <option value="double">double</option>
                            <option value="groove">groove</option>
                            <option value="ridge">ridge</option>
                            <option value="inset">inset</option>
                            <option value="outset">outset</option>
                            <option value="none">none</option>
                            <option value="hidden">hidden</option>
                         </select>
                         <select class="options_type" disabled>
                            <option value="img" disabled="disabled" selected="selected">container or image</option>
                            <option value="container">container</option>
                            <option value="img">img</option>
                            <option value="All">All</option>
                         </select>
                              
                   ';
        }

        if ($name == "image_align$hover$animation"){
            echo '
                 <select class="options" ">
                    <option value="" disabled="disabled" selected="selected">Image Align</option>
                    <option value="left">left</option>
                    <option value="right">right</option>
                    <option value="center">center</option>
                 </select>       
           ';
        }

        if ($effects == 'slide'){
            echo '
                 <select class="options" ">
                            <option value="" disabled="disabled" selected="selected">Slide Effects</option>
                            <option value="slideInDown">slideInDown</option>
                            <option value="slideInLeft">slideInLeft</option>
                            <option value="slideInRight">slideInRight</option>
                            <option value="slideInUp">slideInUp</option>
                            <option value="slideOutDown">slideOutDown</option>
                            <option value="slideOutLeft">slideOutLeft</option>
                            <option value="slideOutRight">slideOutRight</option>
                            <option value="slideOutUp">slideOutUp</option>
                            <option value="none">none</option>
                 </select>  
             ';
        }

        if ($effects == 'fade'){
            echo '
                 <select class="options" ">
                           <option value="" disabled="disabled" selected="selected">Fade Effects</option>
                           <option value="fadeIn">fadeIn</option>
                           <option value="fadeInDown">fadeInDown</option>
                           <option value="fadeInDownBig">fadeInDownBig</option>
                           <option value="fadeInLeft">fadeInLeft</option>
                           <option value="fadeInLeftBig">fadeInLeftBig</option>
                           <option value="fadeInRight">fadeInRight</option>
                           <option value="fadeInRightBig">fadeInRightBig</option>
                           <option value="fadeInUp">fadeInUp</option> 
                           <option value="fadeInUpBig">fadeInUpBig</option>
                           <option value="fadeOut">fadeOut</option>
                           <option value="fadeOutDown">fadeOutDown</option>
                           <option value="fadeOutDownBig">fadeOutDownBig</option>
                           <option value="fadeOutLeft">fadeOutLeft</option>
                           <option value="fadeOutLeftBig">fadeOutLeftBig</option>
                           <option value="fadeOutRight">fadeOutRight</option>
                           <option value="fadeOutRightBig">fadeOutRightBig</option>
                           <option value="fadeOutUp">fadeOutUp</option>
                           <option value="fadeOutUpBig">fadeOutUpBig</option>
                           <option value="none">none</option>
                 </select>  
            ';
        }

        if ($effects == 'zoom'){
            echo '
                 <select class="options" ">
                     <option value="" disabled="disabled" selected="selected">Zoom Effects</option>
                          <option value="zoomIn">zoomIn</option>
                          <option value="zoomInDown">zoomInDown</option>
                          <option value="zoomInLeft">zoomInLeft</option>
                          <option value="zoomInRight">zoomInRight</option>
                          <option value="zoomInUp">zoomInUp</option>
                          <option value="zoomOut">zoomOut</option>
                          <option value="zoomOutDown">zoomOutDown</option>
                          <option value="zoomOutLeft">zoomOutLeft</option> 
                          <option value="zoomOutRight">zoomOutRight</option>
                          <option value="zoomOutUp">zoomOutUp</option>
                          <option value="none">none</option>
                 </select>  
            ';
        }

        if ($effects == 'bounce'){
            echo '
                 <select class="options" ">
                         <option value="" disabled="disabled" selected="selected">Bounce Effects</option>
                         <option value="bounce">bounce</option>
                         <option value="bounceIn">bounceIn</option>
                         <option value="bounceInDown">bounceInDown</option>
                         <option value="bounceInLeft">bounceInLeft</option>
                         <option value="bounceInRight">bounceInRight</option>
                         <option value="bounceInUp">bounceInUp</option>
                         <option value="bounceOut">bounceOut</option>
                         <option value="bounceOutDown">bounceOutDown</option> 
                         <option value="bounceOutLeft">bounceOutLeft</option>
                         <option value="bounceOutRight">bounceOutRight</option>
                         <option value="bounceOutUp">bounceOutUp</option>
                         <option value="none">none</option>
                 </select>  
            ';
        }

        if ($effects == 'flip'){
            echo '
                 <select class="options" ">
                        <option value="" disabled="disabled" selected="selected">Flip Effects</option>
                        <option value="flip">flip</option>
                        <option value="flipInX">flipInX</option>
                        <option value="flipInY">flipInY</option>
                        <option value="flipOutX">flipOutX</option>
                        <option value="flipOutY">flipOutY</option>
                        <option value="none">none</option>
                 </select>  
            ';
        }

        if ($effects == 'rotate'){
            echo '
                 <select class="options" ">
                        <option value="" disabled="disabled" selected="selected">Rotate Effects</option>
                        <option value="rotateIn">rotateIn</option>
                        <option value="rotateInDownLeft">rotateInDownLeft</option>
                        <option value="rotateInDownRight">rotateInDownRight</option>
                        <option value="rotateInUpLeft">rotateInUpLeft</option>
                        <option value="rotateInUpRight">rotateInUpRight</option>
                        <option value="rotateOut">rotateOut</option>
                        <option value="rotateOutDownLeft">rotateOutDownLeft</option>
                        <option value="rotateOutDownRight">rotateOutDownRight</option> 
                        <option value="rotateOutUpLeft">rotateOutUpLeft</option>
                        <option value="rotateOutUpRight">rotateOutUpRight</option>
                        <option value="none">none</option>
                 </select>  
            ';
        }

        if ($effects == 'other'){
            echo '
                 <select class="options" ">
                     <option value="" disabled="disabled" selected="selected">Other Effects</option>
                       <option value="flash">flash</option>
                       <option value="pulse">pulse</option>
                       <option value="rubberBand">rubberBand</option>
                       <option value="shake">shake</option>
                       <option value="swing">swing</option>
                       <option value="tada">tada</option>
                       <option value="wobble">wobble</option>
                       <option value="lightSpeedIn">lightSpeedIn</option> 
                       <option value="lightSpeedOut">lightSpeedOut</option>
                       <option value="none">none</option>
                 </select>  
            ';
        }

    }

    public function numberField($args){

        $value = '';
        $display = '';
        $name = $args['label_for'];
        $placeholder = $args['placeholder'];
        $option_name = $args['option_name'];
        $input = get_option($option_name) ? get_option($option_name) : array ( '' => array ( '' => array ( 'image_width' => '150', 'image_height' => '150', 'image_container_width' => '100', 'image_columns' => '3', 'images_per_page' => '20', 'margin_bottom' => '0', 'margin_top' => '0', 'image_padding' => '0', 'image_opacity' => '1', 'image_z-index' => '0', 'border_size_width_border' => '0', 'border_size_radius_border' => '0', 'image_filter_invert' => '0', 'image_filter_sepia' => '0', 'image_filter_saturate' => '100', 'image_filter_hue-rotate' => '0', 'image_filter_brightness' => '100', 'image_filter_contrast' => '', 'image_transform_translate_x' => '0', 'image_transform_translate_y' => '0', 'image_transform_scale_x' => '1', 'image_transform_scale_y' => '1', 'image_transform_skew_x' => '0', 'image_transform_skew_y' => '0', 'image_transform_rotate' => '0', 'image_box_shadow_x' => '0', 'image_box_shadow_y' => '0', 'image_box_shadow_blur' => '', 'image_box_shadow_spread' => '0', 'write_href' => '', 'write_class' => '', 'write_bg_color' => '', 'border_size_bg_color' => '', 'border_size_border_size-top' => '', 'border_size_border_size-left' => '', 'border_size_border_size-right' => '', 'border_size_border_size-bottom' => '', 'image_box_shadow_bg_color' => '', 'image_width_hover' => '', 'image_height_hover' => '', 'image_container_width_hover' => '', 'margin_bottom_hover' => '', 'margin_top_hover' => '', 'image_padding_hover' => '', 'image_opacity_hover' => '', 'border_size_width_border_hover' => '', 'border_size_radius_border_hover' => '', 'image_filter_invert_hover' => '', 'image_filter_sepia_hover' => '', 'image_filter_saturate_hover' => '', 'image_filter_hue-rotate_hover' => '', 'image_filter_brightness_hover' => '', 'image_filter_contrast_hover' => '', 'image_transform_translate_x_hover' => '', 'image_transform_translate_y_hover' => '', 'image_transform_scale_x_hover' => '', 'image_transform_scale_y_hover' => '', 'image_transform_skew_x_hover' => '', 'image_transform_skew_y_hover' => '', 'image_transform_rotate_hover' => '', 'image_box_shadow_x_hover' => '', 'image_box_shadow_y_hover' => '', 'image_box_shadow_blur_hover' => '', 'image_box_shadow_spread_hover' => '', 'write_bg_color_hover' => '', 'border_size_bg_color_hover' => '', 'border_size_border_size-top_hover' => '', 'border_size_border_size-left_hover' => '', 'border_size_border_size-right_hover' => '', 'border_size_border_size-bottom_hover' => '', 'image_box_shadow_bg_color_hover' => '', 'slide_effects_animation' => '', 'fade_effects_animation' => '', 'zoom_effects_animation' => '', 'bounce_effects_animation' => '', 'flip_effects_animation' => '', 'rotate_effects_animation' => '', 'other_effects_animation' => '', 'duration_animation' => '1000', 'custom_css' => '', ), ), );

        foreach ($input as $key){
            $value = $key;
        }

        $maxName = "max_$name";

        $border = str_replace('border_size','',$name);

        $filter = str_replace('image_filter','',$name);

        $transform = str_replace('image_transform','',$name);

        $box_shadow = str_replace('image_box_shadow','',$name);

        $hover = '';
        $hover_container = str_replace('hover','',$name);
        $hover_class = str_replace($hover_container,'',$name);

        $animation = '';
        $animation_container = str_replace('animation','',$name);
        $animation_class = str_replace($animation_container,'',$name);

        if (!empty($hover_class)){
            $hover = "_$hover_class";
        }

        if (!empty($animation_class)){
            $animation = "_$animation_class";
        }

        $default = [
            "margin_top"                    => 0,
            "image_width"                   => 150,
            "image_height"                  => 150,
            "image_columns"                 => 3,
            "image_padding"                 => 0,
            "image_opacity"                 => 1,
            "image_z-index"                 => 0,
            "margin_bottom"                 => 0,
            "images_per_page"               => 20,
            "image_filter_co"               => 100,
            "image_box_shadow"              => 0,
            "image_box_shadow_x"            => 0,
            "image_box_shadow_y"            => 0,
            "image_box_shadow_blur"         => 0,
            "image_filter_sepia"            => 0,
            "duration_animation"            => 1000,
            "image_filter_invert"           => 0,
            "image_container_width"         => 100,
            "image_filter_saturate"         => 100,
            "image_transform_skew_x"        => 0,
            "image_transform_skew_y"        => 0,
            "image_transform_rotate"        => 0,
            "image_transform_scale_x"       => 1,
            "image_transform_scale_y"       => 1,
            "image_box_shadow_spread"       => 0,
            "image_filter_hue-rotate"       => 0,
            "image_filter_brightness"       => 100,
            "image_filter_contrast"       => 100,
            "border_size_width_border"      => 0,
            "border_size_radius_border"     => 0,
            "image_transform_translate_x"   => 0,
            "image_transform_translate_y"   => 0,


            // Max values

            "max_image_width"               => 3000,
            "max_image_height"              => 2500,
            "max_image_opacity"             => 1,
            "max_image_columns"             => 10,
            "max_images_per_page"           => 60,
            "max_image_transform_s"         => 20,
            "max_image_box_shadow_x"        => 200,
            "max_image_box_shadow_y"        => 200,
            "max_image_filter_sepia"        => 100,
            "max_image_filter_invert"       => 100,
            "max_image_container_width"     => 200,
            "max_image_box_shadow_blur"     => 200,
            "max_image_transform_skew_x"    => 90,
            "max_image_transform_skew_y"    => 90,
            "max_image_transform_rotate"    => 360,
            "max_image_transform_scale_x"   => 20,
            "max_image_box_shadow_spread"   => 200,
            "max_border_size_width_border"  => 200,
            "max_border_size_radius_border" => 200,
        ];

        if ($name == "border_size$border"){
            $border_style = str_replace("$border",'',$name);
            $display = empty($value["$border_style$hover$animation"])  ? 'display-none-parent' : '';
            $border_class = 'my_border_class';
        }

        if ($name === "image_filter$filter" ){
            $image_filter = str_replace("$filter",'',$name);
            $display = empty($value["$image_filter$hover$animation"]) ? 'display-none-parent' : '';
        }

        if ($name === "image_transform$transform" ){
            $image_transform = str_replace("$transform",'',$name);
            $display = empty($value["$image_transform$hover$animation"]) ? 'display-none-parent' : '';
        }

        if ($name === "image_box_shadow$box_shadow" ){
            $image_box_shadow = str_replace("$box_shadow",'',$name);
            $display = empty($value["$image_box_shadow$hover$animation"]) ? 'display-none-parent' : '';
        }

        if (empty($value[$name])){
            $value[$name] = '';
        }

        $value =  $value[$name] !== '' ? $value[$name] : $default[$name];
        $maxNumber = $default[$maxName] ? $default[$maxName] : 1000000000;
        $step = $name == "image_opacity$hover$animation" || $name == "image_transform_scale_x$hover$animation"  || $name == "image_transform_scale_y$hover$animation" ? 0.1 : 1 ;

        if ($name == "duration_animation"){
            $step = 100;
        }

        echo '<input type="number" id="' . $name . '" name="' . $option_name . '['.$name.']" value="'.$value.'" class="regular-number '.$display.'  '.$border_class.' '.$hover_class.' '.$animation_class.'" placeholder="'.$placeholder.'" max="'.$maxNumber.'" step="'.$step.'"">';
    }

    public function checkboxField($args){

        $classes = $args['class'];
        $name = $args['label_for'];
        $option_name = $args['option_name'];
        $input = get_option($option_name) ? get_option($option_name) : unserialize('a:1:{s:0:"";a:81:{s:11:"image_width";s:3:"150";s:12:"image_height";s:3:"150";s:21:"image_container_width";s:3:"100";s:13:"image_columns";s:1:"3";s:15:"images_per_page";s:2:"20";s:13:"margin_bottom";s:1:"0";s:10:"margin_top";s:1:"0";s:13:"image_padding";s:1:"0";s:13:"image_opacity";s:1:"1";s:13:"image_z-index";s:1:"0";s:24:"border_size_width_border";s:1:"0";s:25:"border_size_radius_border";s:1:"0";s:19:"image_filter_invert";s:1:"0";s:18:"image_filter_sepia";s:1:"0";s:21:"image_filter_saturate";s:3:"100";s:23:"image_filter_hue-rotate";s:1:"0";s:23:"image_filter_brightness";s:3:"100";s:21:"image_filter_contrast";s:0:"";s:27:"image_transform_translate_x";s:1:"0";s:27:"image_transform_translate_y";s:1:"0";s:23:"image_transform_scale_x";s:1:"1";s:23:"image_transform_scale_y";s:1:"1";s:22:"image_transform_skew_x";s:1:"0";s:22:"image_transform_skew_y";s:1:"0";s:22:"image_transform_rotate";s:1:"0";s:18:"image_box_shadow_x";s:1:"0";s:18:"image_box_shadow_y";s:1:"0";s:21:"image_box_shadow_blur";s:0:"";s:23:"image_box_shadow_spread";s:1:"0";s:10:"write_href";s:0:"";s:11:"write_class";s:0:"";s:14:"write_bg_color";s:0:"";s:20:"border_size_bg_color";s:0:"";s:27:"border_size_border_size-top";s:0:"";s:28:"border_size_border_size-left";s:0:"";s:29:"border_size_border_size-right";s:0:"";s:30:"border_size_border_size-bottom";s:0:"";s:25:"image_box_shadow_bg_color";s:0:"";s:17:"image_width_hover";s:0:"";s:18:"image_height_hover";s:0:"";s:27:"image_container_width_hover";s:0:"";s:19:"margin_bottom_hover";s:0:"";s:16:"margin_top_hover";s:0:"";s:19:"image_padding_hover";s:0:"";s:19:"image_opacity_hover";s:0:"";s:30:"border_size_width_border_hover";s:0:"";s:31:"border_size_radius_border_hover";s:0:"";s:25:"image_filter_invert_hover";s:0:"";s:24:"image_filter_sepia_hover";s:0:"";s:27:"image_filter_saturate_hover";s:0:"";s:29:"image_filter_hue-rotate_hover";s:0:"";s:29:"image_filter_brightness_hover";s:0:"";s:27:"image_filter_contrast_hover";s:0:"";s:33:"image_transform_translate_x_hover";s:0:"";s:33:"image_transform_translate_y_hover";s:0:"";s:29:"image_transform_scale_x_hover";s:0:"";s:29:"image_transform_scale_y_hover";s:0:"";s:28:"image_transform_skew_x_hover";s:0:"";s:28:"image_transform_skew_y_hover";s:0:"";s:28:"image_transform_rotate_hover";s:0:"";s:24:"image_box_shadow_x_hover";s:0:"";s:24:"image_box_shadow_y_hover";s:0:"";s:27:"image_box_shadow_blur_hover";s:0:"";s:29:"image_box_shadow_spread_hover";s:0:"";s:20:"write_bg_color_hover";s:0:"";s:26:"border_size_bg_color_hover";s:0:"";s:33:"border_size_border_size-top_hover";s:0:"";s:34:"border_size_border_size-left_hover";s:0:"";s:35:"border_size_border_size-right_hover";s:0:"";s:36:"border_size_border_size-bottom_hover";s:0:"";s:31:"image_box_shadow_bg_color_hover";s:0:"";s:23:"slide_effects_animation";s:0:"";s:22:"fade_effects_animation";s:0:"";s:22:"zoom_effects_animation";s:0:"";s:24:"bounce_effects_animation";s:0:"";s:22:"flip_effects_animation";s:0:"";s:24:"rotate_effects_animation";s:0:"";s:23:"other_effects_animation";s:0:"";s:18:"duration_animation";s:4:"1000";s:10:"custom_css";s:0:"";s:29:"global_settings_category_data";s:0:"";}}');

        foreach ($input as $key){
            $checkbox = $key;
        }

        $hover_container = str_replace('hover','',$name);
        $hover_class = str_replace($hover_container,'',$name);

        $animation_container = str_replace('animation','',$name);
        $animation_class = str_replace($animation_container,'',$name);

        $custom_css_container =  str_replace('custom_css','',$name);
        $custom_css_class = str_replace($custom_css_container,'',$name);

        $checked = $checkbox[$name] == 1 ? true : false;

        if ($animation_container == 'active_' || $hover_container == 'active_'){
            $checked = false;
        }

        if ($name == 'active_custom_css'){
            $checked = false;
        }

        echo
            '<div class="' . $classes . '">                
                <input type="checkbox" id="' . $name . '" name="' . $option_name . '['.$name.']" value="1" class="'.$classes.' '.$hover_class.' '.$animation_class.' '.$custom_css_class.'" ' . ( $checked ? 'checked' : '') . '>
                <label for="' . $name . '" class="toggler-wrapper"></label>             
             </div>
        ';

    }

}