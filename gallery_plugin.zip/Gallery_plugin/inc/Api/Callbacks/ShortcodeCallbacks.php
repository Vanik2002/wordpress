<?php

/**
 * @package  GalleryPlugin
 */

namespace Inc\Api\Callbacks;

use Inc\Base\BaseController;

class ShortcodeCallbacks extends BaseController
{


    public function shortCodeSectionManager()
    {
        echo "Crate as many Custom Taxonomies as you want.";
    }

}
