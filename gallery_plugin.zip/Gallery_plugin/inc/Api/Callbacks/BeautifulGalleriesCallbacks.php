<?php

/**
 * @package  GalleryPlugin
 */

namespace Inc\Api\Callbacks;

class BeautifulGalleriesCallbacks
{

    public function BeautifulGalleriesSectionManager(){

        echo "<h4>Add Your Beautiful Gallery</h4>";

    }

    public function BeautifulGalleriesSanitize($input){

        $output = get_option('BeautifulGalleries_settings');

        if (isset($_POST['remove'])){
            unset($output[$_POST['remove']]);
            return $output;
        }

        if (count($output) === 0){
            $output[$input['gallery_title']] = $input;
            return $output;
        }

        foreach ($output as $key => $value){

            if ($input['gallery_title'] === $key){
                $output[$key] = $input;
            }
            else{
                $output[$input['gallery_title']] = $input;
            }
        }
        return $output;

    }

    public function textField($args){

        $value = '';
        $images_src = '';
        $name = $args['label_for'];
        $option_name = $args['option_name'];
        $class = $name == 'gallery_title' ? 'gallery_title_class_display' : '';
        $input = get_option($option_name) ? get_option($option_name) : array();



        foreach ($input as $key){
            $value = $key;
        }

        if ($value !== '' && !$_POST["edit_post"]){
            $value = !empty($value) ? $value[$name] : '';
        }

        if (isset($_POST["edit_post"])){
            $value = $value[$_POST['edit_post']] === $name ? $value[$_POST['edit_post']] : $value[$name];
        }

            $shortcode_name = $name;

            if ($name !== 'post_data'){
                echo '
                <input type="text" id="' . $name . '" name="' . $option_name . '['.$name.']" value="'.$value.'" class="regular-text beautiful_gallery_data'.$class.'" >
                ';
            }
            if ($name === 'post_data'){
                echo '
                <input type="text" id="' . $name . '" name="' . $option_name . '['.$name.']" value="'.$_POST["edit_post"].'" class="regular-text '.$class.'" disabled >
                ';
            }


    }

    public function checkboxField($args)
    {

        $classes = $args['class'];
        $name = $args['label_for'];
        $option_name = $args['option_name'];
        $input = get_option($option_name) ? get_option($option_name) : array();

        foreach ($input as $key) {
            $checkbox = $key;
            $post = $checkbox[$_POST["edit_post"]];
        }

        $edit_post =  $_POST["edit_post"].',';
        $value = str_replace($edit_post,'',$post);

        if(!$_POST["edit_post"]){
            $checked = $checkbox[$name] == 1 ? true : false;
        }
        else{
            $checked = $name === $value ? true : false;
        }

        echo '
              <div class="' . $classes . ' ">                
                  <input type="checkbox" id="' . $name . '" name="' . $option_name . '['.$name.']" value="1" class="beautiful_gallery_checkbox"  ' . ( $checked ? 'checked' : '') . '>
                  <label for="' . $name . '" class="toggler-wrapper"></label>             
             </div>
        ';

    }

}