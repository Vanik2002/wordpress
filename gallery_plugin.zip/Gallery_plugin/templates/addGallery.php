<?php ?>

<div class="wrap">

    <div class="wrapper">
        <div class="bg"><h1>Add Gallery</h1></div>
        <div class="fg"><h1>Add Gallery</h1></div>
    </div>

    <?php settings_errors();?>

    <ul class="nav nav-tabs">
        <li class="<?= !isset($_POST["edit_post"]) ? 'active' : '' ?>"><a href="#tab-1">Galleries</a></li>
        <li class=""><a href="#tab-2">Add New Gallery</a></li>
    <?php if (isset($_POST["edit_post"])){ ?>
        <li class="active"><a href="#tab-3">Add image</a></li>
    <?php } ?>
    </ul>


    <div class="tab-content">
        <div id="tab-1" class="tab-pane <?= !isset($_POST["edit_post"]) ? 'active' : '' ?> table_container">
            <?php
            $options = get_option('addGallery_settings') ?: array();
            echo '
                 <div class="black-lives-matter_container">
                    <h2 class="black-lives-matter">Your Galleries</h2>
                 </div>
            ';
            echo '
                 <table> .
                   <thead>
                     <tr>
                        <th>Gallery title</th>
                        <th class="center">Actions</th>
                     </tr>
                   </thead>
           ';
                    foreach ($options as $option){
                        echo "
                            <tr>
                                <td class='center'>{$option['gallery_title']}</td>
                                <td class='center'>";
                            echo "
                                   <form method='post' action='' class='inline-block'>";
                                    echo "
                                         <input type='hidden' name='edit_post' value='".$option['gallery_title']."'>
                                    ";
                                         submit_button("Edit","primary small" ,"submit",false);
                            echo " </form>";
                            echo "
                                   <form method='post' action='options.php' class='inline-block'>";
                                         settings_fields('gallery_plugin_addGallery_settings');
                                         submit_button("Delete","delete small" ,"submit",false ,array(
                                            'onclick' => 'return confirm("Are you sure you want to delete this Custom Post Type? The data associated with it will not be deleted")',
                                         ));
                                   echo  "
                                         <input type='hidden' name='remove' value='".$option["gallery_title"]."'>
                                   ";
                            echo " </form>                                     
                                </td>      
                            </tr>
                        ";
                    }
            echo '</table>';
            ?>
        </div>
        <div id="tab-2" class="tab-pane add_gallery_container">
            <form method="post" action="options.php">
                <?php
                settings_fields('gallery_plugin_addGallery_settings');
                do_settings_sections('addGallery_settings');
                submit_button("Add Gallery","secondary" ,"add_gallery",'true')
                ?>
            </form>
        </div>
        <div id="tab-3" class="tab-pane gallery_form_container <?= isset($_POST["edit_post"]) ? 'active' : '' ?>">
            <form method="post" action="options.php">
                <?php
                settings_fields('gallery_plugin_addGallery_settings');
                do_settings_sections('addGallery_settings');

                if (isset($_POST["edit_post"])){
                    submit_button("Save Gallery","primary" ,"save_gallery",'true');
                }

                ?>
            </form>
        </div>
    </div>
</div>

