<?php
?>

<div class="wrap">
    <div class="wrapper">
        <div class="bg"><h1>JS Code Editor</h1></div>
        <div class="fg"><h1>JS Code Editor</h1></div>
    </div>

    <?php settings_errors();?>

    <ul class="nav nav-tabs">
        <li class="tab-1-custom-js-container active">
            <a href="#tab-1">Custom JS</a>
        </li>
    </ul>
    <div class="tab-content">
        <div id="tab-1" class="tab-pane  custom_js_container active">
            <form method="post" action="options.php">
                <?php
                settings_fields('gallery_plugin_js_settings');
                do_settings_sections('js_settings');
                submit_button("Save Custom Js",'primary','submit_custom_js');
                ?>
            </form>
        </div>
    </div>
</div>
