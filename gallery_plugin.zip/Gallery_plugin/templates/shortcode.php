<?php
?>
<div class="wrap">
    <div class="wrapper">
        <div class="bg"><h1>Gallery shortcode</h1></div>
        <div class="fg"><h1>Gallery shortcode</h1></div>
    </div>
    <div class="shortcode_container">
        <?php
            $options = get_option('addGallery_settings') ? get_option('addGallery_settings') : array();

            foreach ($options as $option){

                $shortcode = $option['gallery_title']
        ?>
                <div class="black-lives-matter_container">
                    <h2 class="black-lives-matter">[<?php echo do_shortcode($shortcode);?>]</h2>
                </div>

      <?php }  ?>

                <h3 class="copied_container"><span class="copied">COPIED</span></h3>
    </div>
</div>