<div id="my_input_data" style="position: absolute;opacity: 0"></div>

<script>

    jQuery(document).ready(function(){let s=jQuery("#custom_css").val(),t="",c="",e="";jQuery("#img_style_generator_custom_css").prop("checked")?jQuery("#custom_css,.CodeMirror").on("click keyup",function(){jQuery(".custom_css_container").hasClass("active")&&(jQuery(".CodeMirror-code pre span span").addClass("my_value"),e="",jQuery(".CodeMirror-code pre>span").each(function(){c=jQuery(this).html().replaceAll("&nbsp;",""),t=jQuery("my_input_data").html(),jQuery("#my_input_data").html(c),s=jQuery("#my_input_data").text(),e=e.concat(s)}),jQuery("#my_custom_css_styles").text(e))}):jQuery("#my_custom_css_styles").text(s)});

</script>


