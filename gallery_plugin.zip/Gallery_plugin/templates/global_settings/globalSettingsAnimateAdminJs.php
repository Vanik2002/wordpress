


<script>

    jQuery(document).ready(function(){let a=jQuery(".gallery_image_container").attr("class").replace("gallery_image_container ","");jQuery(".options,.default_container,#duration_animation").on("click keyup",function(){if(jQuery(".animation_container").hasClass("active")){if("duration_animation"===jQuery(this).attr("id")){let i=jQuery(this).val();jQuery(".gallery_image_container").css("animation-duration",`${i}ms`)}else{a=jQuery(".gallery_image_container").attr("class").replace("gallery_image_container","");let e=jQuery(this).siblings("input").val();jQuery(".gallery_image_container").removeClass(a),jQuery(".gallery_image_container").addClass(e)}}})});

</script>


