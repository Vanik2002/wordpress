<?php

$image_count = 0;
$shortcode_value = '';
global $post;

$options = get_option('addGallery_settings') ?: array();


foreach ($options as $option){

    $value = $option;
    $shortcode_boolean =  has_shortcode( $post->post_content,$value['gallery_title']) ? $value['gallery_title'] : '';

    if (!empty($shortcode_boolean)){
        $shortcode_value = $value['gallery_title'];
        $value = $value[$shortcode_value];
    }

}
$size_settings = get_option($shortcode_value.'gallery_global_settings') ?: array();
if (empty($shortcode_value)){
    $size_settings = get_option('widgetsgallery_global_settings') ?: array();
}

foreach ($size_settings as $sizes){

    $effects = $sizes;

    //width

    $image_width  = $sizes['image_width'] === '' || empty($sizes['image_width']) ? 150 .'px' : $sizes['image_width'].'px';
    $image_width_hover = $sizes['image_width_hover'] === '' || empty($sizes['image_width_hover']) ? $image_width : $sizes['image_width_hover'].'px';

    $image_container_width  = $sizes['image_container_width'] === '' || empty($sizes['image_container_width']) ? 100 . '%' : $sizes['image_container_width'].'%';
    $image_container_width_hover  = $sizes['image_container_width_hover'] === '' || empty($sizes['image_container_width_hover']) ? $image_container_width : $sizes['image_container_width_hover'].'%';

    //height

    $image_height  = $sizes['image_height'] === '' || empty($sizes['image_height']) ? 150 .'px' : $sizes['image_height'].'px';
    $image_height_hover  = $sizes['image_height_hover'] === '' || empty($sizes['image_height_hover']) ? $image_height : $sizes['image_height_hover'].'px';

    //margins

    $margin_bottom  = $sizes['margin_bottom'] === '' || empty($sizes['margin_bottom']) ? 0  : $sizes['margin_bottom'].'px';
    $margin_bottom_hover  = $sizes['margin_bottom_hover'] === '' || empty($sizes['margin_bottom_hover']) ? $margin_bottom  : $sizes['margin_bottom_hover'].'px';

    $margin_top  = $sizes['margin_top'] === '' || empty($sizes['margin_top']) ? 0 : $sizes['margin_top'].'px';
    $margin_top_hover  = $sizes['margin_top_hover'] === '' || empty($sizes['margin_top_hover']) ? $margin_top : $sizes['margin_top_hover'].'px';

    //padding

    $image_padding  = $sizes['image_padding'] === '' || empty($sizes['image_padding']) ? 0 : $sizes['image_padding'].'px';
    $image_padding_hover  = $sizes['image_padding_hover'] === '' || empty($sizes['image_padding_hover']) ? $image_padding : $sizes['image_padding_hover'].'px';

    //opacity

    $image_opacity = $sizes['image_opacity'] === '' || empty($sizes['image_opacity']) ? 1 : $sizes['image_opacity'];
    $image_opacity_hover = $sizes['image_opacity_hover'] === '' || empty($sizes['image_opacity_hover']) ? $image_opacity : $sizes['image_opacity_hover'];

    //z-index

    $image_index = $sizes['image_z-index'] === '' || empty($sizes['image_z-index']) ? 0 : $sizes['image_z-index'];

    //float

    $float = $sizes['image_align'] === ''  ? 'unset' : $sizes['image_align'];
    $float = $float === 'center' ? 'none' : $float;
    $float_hover = $sizes['image_align_hover'] === ''  ? $float : $sizes['image_align_hover'];
    $float_hover = $float_hover === 'center' ? 'none' : $float_hover;

    //filters

    $image_filter_invert = $sizes['image_filter_invert'] === '' || empty($sizes['image_filter_invert']) ? 0 : $sizes['image_filter_invert']. '%';
    $image_filter_sepia =  $sizes['image_filter_sepia'] === '' || empty($sizes['image_filter_sepia']) ? 0 : $sizes['image_filter_sepia']. '%';
    $image_filter_saturate =  $sizes['image_filter_saturate'] === '' || empty($sizes['image_filter_saturate']) ? '100%' : $sizes['image_filter_saturate']. '%';
    $image_filter_brightness =  $sizes['image_filter_brightness'] === '' || empty($sizes['image_filter_brightness']) ? '100%' : $sizes['image_filter_brightness']. '%';
    $image_filter_contrast =  $sizes['image_filter_contrast'] === '' || empty($sizes['image_filter_contrast']) ? '100%' : $sizes['image_filter_contrast']. '%';
    $image_filter_hue_rotate =  $sizes['image_filter_hue-rotate'] === '' || empty($sizes['image_filter_hue-rotate']) ? 0 : $sizes['image_filter_hue-rotate']. 'deg';

    $image_filter_invert_hover = $sizes['image_filter_invert_hover'] === '' || empty($sizes['image_filter_invert_hover']) ? $image_filter_invert : $sizes['image_filter_invert_hover']. '%';
    $image_filter_sepia_hover =  $sizes['image_filter_sepia_hover'] === '' || empty($sizes['image_filter_sepia_hover']) ? $image_filter_sepia : $sizes['image_filter_sepia_hover']. '%';
    $image_filter_saturate_hover =  $sizes['image_filter_saturate_hover'] === '' || empty($sizes['image_filter_saturate_hover']) ? $image_filter_brightness : $sizes['image_filter_saturate_hover']. '%';
    $image_filter_brightness_hover =  $sizes['image_filter_brightness_hover'] === '' || empty($sizes['image_filter_brightness_hover']) ? $image_filter_saturate : $sizes['image_filter_brightness_hover']. '%';
    $image_filter_contrast_hover =  $sizes['image_filter_contrast_hover'] === '' || empty($sizes['image_filter_contrast_hover']) ? $image_filter_contrast : $sizes['image_filter_contrast_hover']. '%';
    $image_filter_hue_rotate_hover =  $sizes['image_filter_hue-rotate_hover'] === '' || empty($sizes['image_filter_hue-rotate_hover']) ? $image_filter_hue_rotate : $sizes['image_filter_hue-rotate_hover']. 'deg';
    //transforms

    $image_transform_translate_x =  $sizes['image_transform_translate_x'] === '' || empty($sizes['image_transform_translate_x']) ? 0 : $sizes['image_transform_translate_x']. 'px';
    $image_transform_translate_y =  $sizes['image_transform_translate_y'] === '' || empty($sizes['image_transform_translate_y']) ? 0 : $sizes['image_transform_translate_y']. 'px';
    $image_transform_scale_x =  $sizes['image_transform_scale_x'] === '' || empty($sizes['image_transform_scale_x']) ? 1 : $sizes['image_transform_scale_x'];
    $image_transform_scale_y =  $sizes['image_transform_scale_y'] === '' || empty($sizes['image_transform_scale_y']) ? 1 : $sizes['image_transform_scale_y'];
    $image_transform_skew_x =  $sizes['image_transform_skew_x'] === '' || empty($sizes['image_transform_skew_x']) ? 0 : $sizes['image_transform_skew_x']. 'deg';
    $image_transform_skew_y =  $sizes['image_transform_skew_y'] === '' || empty($sizes['image_transform_skew_y']) ? 0 : $sizes['image_transform_skew_y']. 'deg';
    $image_transform_rotate =  $sizes['image_transform_rotate'] === '' || empty($sizes['image_transform_rotate']) ? 0 : $sizes['image_transform_rotate']. 'deg';

    $image_transform_translate_x_hover =  $sizes['image_transform_translate_x_hover'] === '' || empty($sizes['image_transform_translate_x_hover']) ? $image_transform_translate_x : $sizes['image_transform_translate_x_hover']. 'px';
    $image_transform_translate_y_hover =  $sizes['image_transform_translate_y_hover'] === '' || empty($sizes['image_transform_translate_y_hover']) ? $image_transform_translate_y : $sizes['image_transform_translate_y_hover']. 'px';
    $image_transform_scale_x_hover =  $sizes['image_transform_scale_x_hover'] === '' || empty($sizes['image_transform_scale_x_hover']) ? $image_transform_scale_x : $sizes['image_transform_scale_x_hover'];
    $image_transform_scale_y_hover =  $sizes['image_transform_scale_y_hover'] === '' || empty($sizes['image_transform_scale_y_hover']) ? $image_transform_scale_y : $sizes['image_transform_scale_y_hover'];
    $image_transform_skew_x_hover =  $sizes['image_transform_skew_x_hover'] === '' || empty($sizes['image_transform_skew_x_hover']) ? $image_transform_skew_x : $sizes['image_transform_skew_x_hover']. 'deg';
    $image_transform_skew_y_hover =  $sizes['image_transform_skew_y_hover'] === '' || empty($sizes['image_transform_skew_y_hover']) ? $image_transform_skew_y : $sizes['image_transform_skew_y_hover']. 'deg';
    $image_transform_rotate_hover =  $sizes['image_transform_rotate_hover'] === '' || empty($sizes['image_transform_rotate_hover']) ? $image_transform_rotate : $sizes['image_transform_rotate_hover']. 'deg';

    //box-shadows

    $image_box_shadow_x =  $sizes['image_box_shadow_x'] === '' || empty($sizes['image_box_shadow_x']) ? 0 : $sizes['image_box_shadow_x']. 'px';
    $image_box_shadow_y =  $sizes['image_box_shadow_y'] === '' || empty($sizes['image_box_shadow_y']) ? 0 : $sizes['image_box_shadow_y']. 'px';
    $image_box_shadow_blur =  $sizes['image_box_shadow_blur'] === '' || empty($sizes['image_box_shadow_blur']) ? 0 : $sizes['image_box_shadow_blur']. 'px';
    $image_box_shadow_spread =  $sizes['image_box_shadow_spread'] === '' || empty($sizes['image_box_shadow_spread']) ? 0 : $sizes['image_box_shadow_spread']. 'px';
    $image_box_shadow_bg_color = $sizes['image_box_shadow_bg_color'] === ''  || empty($sizes['image_box_shadow_bg_color']) ? 'white' : $sizes['image_box_shadow_bg_color'];

    $image_box_shadow_x_hover =  $sizes['image_box_shadow_x_hover'] === '' || empty($sizes['image_box_shadow_x_hover']) ? $image_box_shadow_x : $sizes['image_box_shadow_x_hover']. 'px';
    $image_box_shadow_y_hover =  $sizes['image_box_shadow_y_hover'] === '' || empty($sizes['image_box_shadow_y_hover']) ? $image_box_shadow_y : $sizes['image_box_shadow_y_hover']. 'px';
    $image_box_shadow_blur_hover =  $sizes['image_box_shadow_blur_hover'] === '' || empty($sizes['image_box_shadow_blur_hover']) ? $image_box_shadow_blur : $sizes['image_box_shadow_blur_hover']. 'px';
    $image_box_shadow_spread_hover =  $sizes['image_box_shadow_spread_hover'] === '' || empty($sizes['image_box_shadow_spread_hover']) ? $image_box_shadow_spread : $sizes['image_box_shadow_spread_hover']. 'px';
    $image_box_shadow_bg_color_hover = $sizes['image_box_shadow_bg_color_hover'] === ''  || empty($sizes['image_box_shadow_bg_color_hover']) ? $image_box_shadow_bg_color : $sizes['image_box_shadow_bg_color_hover'];

    // columns

    $image_columns = $sizes['image_columns'] === '' || empty($sizes['image_columns']) ? 100 / 3 .'%' : 100 / $sizes['image_columns'] . '%';
    $images_per_page = $sizes['images_per_page'] === '' || empty($sizes['images_per_page']) ? 60 : $sizes['images_per_page'];

    //bg_color

    $bg_color = $sizes['write_bg_color'] === ''  || empty($sizes['bg_color']) ? '' : $sizes['write_bg_color'];
    $bg_color_hover = $sizes['write_bg_color_hover'] === ''  || empty($sizes['write_bg_color_hover']) ? $bg_color : $sizes['write_bg_color_hover'];

    //href

    $href = $sizes['write_href'] === '' || empty($sizes['href'])  ? '#' : $sizes['write_href'];

    //class

    $class = $sizes['write_class'] === ''  || empty($sizes['class']) ? '' : $sizes['write_class'];

    //borders

    $border_width =  $sizes['border_size_width_border'] === '' || empty($sizes['border_size_width_border']) ? 0 : $sizes['border_size_width_border'];
    $border_radius = $sizes['border_size_radius_border'] === '' || empty($sizes['border_size_radius_border']) ? 0 : $sizes['border_size_radius_border'];
    $border_width_hover =  $sizes['border_size_width_border_hover'] === '' || empty($sizes['border_size_width_border_hover']) ? $border_width : $sizes['border_size_width_border_hover'];
    $border_radius_hover = $sizes['border_size_radius_border_hover'] === '' || empty($sizes['border_size_radius_border_hover']) ? $border_radius : $sizes['border_size_radius_border_hover'];
    $border_color = $sizes['border_size_bg_color'] === ''  || empty($sizes['border_size']) ? 'black' : $sizes['border_size_bg_color'];

    $border_style_top = $sizes['border_size_border_size-top'] === ''  || empty($sizes['border_size']) ? 'none' : $sizes['border_size_border_size-top'];
    $border_style_left = $sizes['border_size_border_size-left'] === ''  || empty($sizes['border_size']) ? 'none' : $sizes['border_size_border_size-left'];
    $border_style_right = $sizes['border_size_border_size-right'] === ''  || empty($sizes['border_size']) ? 'none' : $sizes['border_size_border_size-right'];
    $border_style_bottom = $sizes['border_size_border_size-bottom'] === ''  || empty($sizes['border_size']) ? 'none' : $sizes['border_size_border_size-bottom'];
    $border_color_hover = $sizes['border_size_bg_color_hover'] === ''  || empty($sizes['border_size_hover']) ? $border_color : $sizes['border_size_bg_color_hover'];
    $border_style_top_hover = $sizes['border_size_border_size-top_hover'] === ''  || empty($sizes['border_size_hover']) ? $border_style_top : $sizes['border_size_border_size-top_hover'];
    $border_style_left_hover = $sizes['border_size_border_size-left_hover'] === ''  || empty($sizes['border_size_hover']) ? $border_style_left : $sizes['border_size_border_size-left_hover'];
    $border_style_right_hover = $sizes['border_size_border_size-right_hover'] === ''  || empty($sizes['border_size_hover']) ? $border_style_right : $sizes['border_size_border_size-right_hover'];
    $border_style_bottom_hover = $sizes['border_size_border_size-bottom_hover'] === ''  || empty($sizes['border_size_hover']) ? $border_style_bottom : $sizes['border_size_border_size-bottom_hover'];

    $container_boolean_top =  strpos($border_style_top,'(container)') ? true : false;
    $container_boolean_left =  strpos($border_style_left,'(container)') ? true : false;
    $container_boolean_right =  strpos($border_style_right,'(container)') ? true : false;
    $container_boolean_bottom =  strpos($border_style_bottom,'(container)') ? true : false;
    $container_boolean_top_hover =  strpos($border_style_top_hover,'(container)') ? true : false;
    $container_boolean_left_hover =  strpos($border_style_left_hover,'(container)') ? true : false;
    $container_boolean_right_hover =  strpos($border_style_right_hover,'(container)') ? true : false;
    $container_boolean_bottom_hover =  strpos($border_style_bottom_hover,'(container)') ? true : false;

    $container_boolean_top =  strpos($border_style_top,'(All)') ? true : $container_boolean_top;
    $container_boolean_left =  strpos($border_style_left,'(All)') ? true : $container_boolean_left;
    $container_boolean_right =  strpos($border_style_right,'(All)') ? true : $container_boolean_right;
    $container_boolean_bottom =  strpos($border_style_bottom,'(All)') ? true : $container_boolean_bottom;
    $container_boolean_top_hover =  strpos($border_style_top_hover,'(All)') ? true : $container_boolean_top_hover;
    $container_boolean_left_hover =  strpos($border_style_left_hover,'(All)') ? true : $container_boolean_left_hover;
    $container_boolean_right_hover =  strpos($border_style_right_hover,'(All)') ? true : $container_boolean_right_hover;
    $container_boolean_bottom_hover =  strpos($border_style_bottom_hover,'(All)') ? true : $container_boolean_bottom_hover;

    $img_boolean_top =  strpos($border_style_top,'(img)') ? true : false;
    $img_boolean_left =  strpos($border_style_left,'(img)') ? true : false;
    $img_boolean_right =  strpos($border_style_right,'(img)') ? true : false;
    $img_boolean_bottom =  strpos($border_style_bottom,'(img)') ? true : false;
    $img_boolean_top_hover =  strpos($border_style_top_hover,'(img)') ? true : false;
    $img_boolean_left_hover =  strpos($border_style_left_hover,'(img)') ? true : false;
    $img_boolean_right_hover =  strpos($border_style_right_hover,'(img)') ? true : false;
    $img_boolean_bottom_hover=  strpos($border_style_bottom_hover,'(img)') ? true : false;

    $img_boolean_top =  strpos($border_style_top,'(All)') ? true : $img_boolean_top;
    $img_boolean_left =  strpos($border_style_left,'(All)') ? true : $img_boolean_left;
    $img_boolean_right =  strpos($border_style_right,'(All)') ? true : $img_boolean_right;
    $img_boolean_bottom =  strpos($border_style_bottom,'(All)') ? true : $img_boolean_bottom;
    $img_boolean_top_hover =  strpos($border_style_top_hover,'(All)') ? true : $img_boolean_top_hover;
    $img_boolean_left_hover =  strpos($border_style_left_hover,'(All)') ? true : $img_boolean_left_hover;
    $img_boolean_right_hover =  strpos($border_style_right_hover,'(All)') ? true : $img_boolean_right_hover;
    $img_boolean_bottom_hover=  strpos($border_style_bottom_hover,'(All)') ? true : $img_boolean_bottom_hover;

    $border_style_top = $border_style_top == $sizes['border_size_border_size-top'] && $border_style_top !== "" && $container_boolean_top ? str_replace('(container)','',$border_style_top) :  str_replace('(img)','',$border_style_top);
    $border_style_top = $border_style_top == $sizes['border_size_border_size-top'] && $border_style_top !== "" && $container_boolean_top ? str_replace('(All)','',$border_style_top) :  str_replace('(All)','',$border_style_top);
    $border_style_left = $border_style_left == $sizes['border_size_border_size-left'] && $border_style_left !== "" &&  $container_boolean_left  ? str_replace('(container)','',$border_style_left) :  str_replace('(img)','',$border_style_left);
    $border_style_left = $border_style_left == $sizes['border_size_border_size-left'] && $border_style_left !== "" &&  $container_boolean_left  ? str_replace('(All)','',$border_style_left) :  str_replace('(All)','',$border_style_left);
    $border_style_right = $border_style_right == $sizes['border_size_border_size-right'] && $border_style_right !== "" &&  $container_boolean_right ? str_replace('(container)','',$border_style_right) :  str_replace('(img)','',$border_style_right);
    $border_style_right = $border_style_right == $sizes['border_size_border_size-right'] && $border_style_right !== "" &&  $container_boolean_right ? str_replace('(All)','',$border_style_right) :  str_replace('(All)','',$border_style_right);
    $border_style_bottom = $border_style_bottom == $sizes['border_size_border_size-bottom'] && $border_style_bottom !== "" &&  $container_boolean_bottom ? str_replace('(container)','',$border_style_bottom) :  str_replace('(img)','',$border_style_bottom);
    $border_style_bottom = $border_style_bottom == $sizes['border_size_border_size-bottom'] && $border_style_bottom !== "" &&  $container_boolean_bottom ? str_replace('(All)','',$border_style_bottom) :  str_replace('(All)','',$border_style_bottom);
    $border_style_top_hover = $border_style_top_hover == $sizes['border_size_border_size-top_hover'] && $border_style_top_hover !== "" && $container_boolean_top_hover ? str_replace('(container)','',$border_style_top_hover) :  str_replace('(img)','',$border_style_top_hover);
    $border_style_top_hover = $border_style_top_hover == $sizes['border_size_border_size-top_hover'] && $border_style_top_hover !== "" && $container_boolean_top_hover ? str_replace('(All)','',$border_style_top_hover) :  str_replace('(All)','',$border_style_top_hover);
    $border_style_left_hover = $border_style_left_hover == $sizes['border_size_border_size-left_hover'] && $border_style_left_hover !== "" &&  $container_boolean_left_hover  ? str_replace('(container)','',$border_style_left_hover) :  str_replace('(img)','',$border_style_left_hover);
    $border_style_left_hover = $border_style_left_hover == $sizes['border_size_border_size-left_hover'] && $border_style_left_hover !== "" &&  $container_boolean_left_hover  ? str_replace('(All)','',$border_style_left_hover) :  str_replace('(All)','',$border_style_left_hover);
    $border_style_right_hover = $border_style_right_hover == $sizes['border_size_border_size-right_hover'] && $border_style_right_hover !== "" &&  $container_boolean_right_hover ? str_replace('(container)','',$border_style_right_hover) :  str_replace('(img)','',$border_style_right_hover);
    $border_style_right_hover = $border_style_right_hover == $sizes['border_size_border_size-right_hover'] && $border_style_right_hover !== "" &&  $container_boolean_right_hover ? str_replace('(All)','',$border_style_right_hover) :  str_replace('(All)','',$border_style_right_hover);
    $border_style_bottom_hover = $border_style_bottom_hover == $sizes['border_size_border_size-bottom_hover'] && $border_style_bottom_hover !== "" &&  $container_boolean_bottom_hover ? str_replace('(container)','',$border_style_bottom_hover) :  str_replace('(img)','',$border_style_bottom_hover);
    $border_style_bottom_hover = $border_style_bottom_hover == $sizes['border_size_border_size-bottom_hover'] && $border_style_bottom_hover !== "" &&  $container_boolean_bottom_hover ? str_replace('(All)','',$border_style_bottom_hover) :  str_replace('(All)','',$border_style_bottom_hover);

    $border_style_top_container = $container_boolean_top ? $border_style_top : 'none';
    $border_style_left_container = $container_boolean_left ? $border_style_left : 'none';
    $border_style_right_container = $container_boolean_right ? $border_style_right : 'none';
    $border_style_bottom_container = $container_boolean_bottom ? $border_style_bottom : 'none';
    $border_style_top_container_hover = $container_boolean_top_hover ? $border_style_top_hover : $border_style_top_container;
    $border_style_left_container_hover = $container_boolean_left_hover ? $border_style_left_hover : $border_style_left_container;
    $border_style_right_container_hover = $container_boolean_right_hover ? $border_style_right_hover : $border_style_right_container;
    $border_style_bottom_container_hover = $container_boolean_bottom_hover ? $border_style_bottom_hover : $border_style_bottom_container;
    $border_style_top = !$container_boolean_top || $img_boolean_top ? $border_style_top : 'none';
    $border_style_left = !$container_boolean_left || $img_boolean_left ? $border_style_left : 'none';
    $border_style_right = !$container_boolean_right || $img_boolean_right ? $border_style_right : 'none';
    $border_style_bottom = !$container_boolean_bottom || $img_boolean_bottom ?  $border_style_bottom : 'none';

    $border_style_top_hover = !$container_boolean_top_hover || $img_boolean_top_hover ? $border_style_top_hover : $border_style_top;
    $border_style_left_hover = !$container_boolean_left_hover || $img_boolean_left_hover ? $border_style_left_hover : $border_style_left;
    $border_style_right_hover = !$container_boolean_right_hover || $img_boolean_right_hover ? $border_style_right_hover : $border_style_right;
    $border_style_bottom_hover = !$container_boolean_bottom_hover || $img_boolean_bottom_hover ?  $border_style_bottom_hover : $border_style_bottom;

    //animation

    $animation_duration =  $sizes['duration_animation'] === '' || empty($sizes['duration_animation']) ? '1000ms' : $sizes['duration_animation'] . "ms";

    //custom css

    $custom_css = $sizes['custom_css'] === ''  ? '' : $sizes['custom_css'];

}