
<?php

$href = '';
$class = '';
$float = '';
$value = '';
$image_src = '';
$js_option = '';
$image_index = '';
$image_count = '';
$effects = array();
$image_columns = '';
$shortcode_value = '';
$images_per_page = '';
$beautiful_gallery_value = '';

include 'globalSettingsAdminStyles.php';

global $post;

$options = get_option('addGallery_settings') ?: array();
$beautiful_gallery_options = get_option('beautifulGalleries_settings') ? get_option('beautifulGalleries_settings') : array();

foreach ($beautiful_gallery_options as $option){
    $beautiful_gallery_value = $option;
}

foreach ($options as $key => $value) {
    $images_src .= ",".$value[$key];


}

$image_src_array = explode(',',$images_src);

$effect_class = '';

foreach ($effects as $effect => $value){

    $effect_name = str_replace('effects_animation','',$effect);
    $effect_animation = str_replace($effect_name,'',$effect);

    if ($effect_animation == 'effects_animation' && $value !== ''){
        $effect_class = $value;
    }

}

 if( $image_src_array !== '' && !empty($image_src_array)) {
    echo '  
            <input type="hidden" data-name="translate('.$image_transform_translate_x.','.$image_transform_translate_y.')
                                           scale('.$image_transform_scale_x.','.$image_transform_scale_y.') 
                                           skew('.$image_transform_skew_x.','.$image_transform_skew_y.') 
                                           rotate('.$image_transform_rotate.')" class="transform_data">
          <div class="e-gallery-container gallery_container background-color" style=display: flex; flex-wrap: wrap; justify-content: flex-start;margin: auto; z-index: '.$image_index.'">
    ';
    foreach ($image_src_array as $id) {
        if ($id !== ''){
            $image_count++;
            if ($image_count <= $images_per_page) {
                echo '
                          <div class="gallery_image_container ' . $effect_class . '" style="width: ' . $image_columns . ';padding: 20px;text-align: center;">
                                <a href="' . $href . '">
                                    <img src="' . $id . '" alt=""" class="' . $class . '">
                                </a>
                          </div>';
            }
        }
    }

    echo '</div>';

}

$js_options = get_option('js_settings') ?: array();

foreach ($js_options as $option){
    $js_option = $option;
}

if (!empty($sizes['img_style_generator'])) {
    include_once 'globalSettingsAdminJs.php';
}

if (!empty($sizes['img_style_generator_hover'])) {
    include_once 'globalSettingsHoverAdminJs.php';
}

if (!empty($sizes['img_style_generator_animation'])) {
    include_once 'globalSettingsAnimateAdminJs.php';
}

if (!empty($sizes['img_style_generator_custom_css'])) {
    include_once 'globalSettingsCustomCssAdminJs.php';
}

$js_value = $js_option['custom_Js'];



if (!empty($js_value)){
    get_footer();
    ?>
    <script id="myJs">

        <?php  echo $js_value ?>

    </script>

    <?php

}










