
<?php

$href = '';
$class = '';
$float = '';
$value = '';
$image_src = '';
$js_option = '';
$margin_top = '';
$image_index = '';
$image_width = '';
$image_count = '';
$image_height = '';
$effects = array();
$image_opacity = '';
$image_padding = '';
$image_columns = '';
$margin_bottom = '';
$shortcode_value = '';
$images_per_page = '';
$image_container_width = '';
$beautiful_gallery_value = '';

include 'global_settings/globalSettingsValues.php';

global $post;

$options = get_option('addGallery_settings') ?: array();
$beautiful_gallery_options = get_option('beautifulGalleries_settings') ? get_option('beautifulGalleries_settings') : array();

foreach ($beautiful_gallery_options as $option){
    $beautiful_gallery_value = $option;
}

foreach ($options as $option){

    $value = $option;
    $shortcode_boolean =  has_shortcode( $post->post_content,$value['gallery_title']) ? $value['gallery_title'] : '';

    if (!empty($shortcode_boolean)){
        $shortcode_value = $value['gallery_title'];
        $value = $value[$shortcode_value];
        $image_src = $value;
    }

}

$image_src_array = explode(',',$image_src);
$effect_class = '';

foreach ($effects as $effect => $value){

    $effect_name = str_replace('effects_animation','',$effect);
    $effect_animation = str_replace($effect_name,'',$effect);

    if ($effect_animation == 'effects_animation' && $value !== ''){
        $effect_class = $value;
    }

}

//post

if (!empty( $image_src !== '' && !empty($image_src) && $beautiful_gallery_value[$shortcode_value])){
    include "beautiful_galleries/beautiful_gallery_style.php";
    include "beautiful_galleries/beautiful_gallery_front.php";
}
else if( $image_src !== '' && !empty($image_src) && empty($beautiful_gallery_value[$shortcode_value])) {
    echo '  
          <div class="e-gallery-container gallery_container background-color" style="width: ' . $image_container_width . ';display: flex; flex-wrap: wrap; justify-content: flex-start;margin: auto; z-index: '.$image_index.'">
    ';
            foreach ($image_src_array as $id) {
                $image_count++;

                if ($image_count <= $images_per_page) {
                    echo '
                          <div class="gallery_image_container ' . $effect_class . '" style="width: ' . $image_columns . ';margin-top: ' . $margin_top . '; margin-bottom: ' . $margin_bottom . ';padding: 20px;text-align: center;">
                                <a href="' . $href . '">
                                    <img src="' . $id . '" alt=""" class="' . $class . '"  style=" width:' . $image_width . '; height:' . $image_height . '; float: ' . $float . ';padding: ' . $image_padding . ';opacity: ' . $image_opacity . ';">
                                </a>
                          </div>';
                }

            }

    echo '</div>';

}

    $js_options = get_option('js_settings') ?: array();

    foreach ($js_options as $option){
        $js_option = $option;
    }

    $js_value = $js_option['custom_Js'];

        if (!empty($js_value)){
            get_footer();
            ?>
            <script id="myJs">

                <?php  echo $js_value ?>

            </script>

            <?php

        }









