<?php

    $options = get_option($_SESSION['edit_post'].'gallery_global_settings') ? get_option($_SESSION['edit_post'].'gallery_global_settings') : array();

    foreach ($options as $option) {
            $active = $option;
        }
    $edit_post = $_POST["edit_post"] ? $_POST["edit_post"] : '';

    $tab2_active = empty($active['active_hover'])  && empty($active['active_animation']) && empty($active['active_custom_css']) ? true : false;

    session_start();

?>

<div class="wrap">
    <div class="wrapper">
        <div class="bg"><h1>Global Settings</h1></div>
        <div class="fg"><h1>Global Settings</h1></div>
    </div>

    <?php settings_errors();?>

    <ul class="nav nav-tabs">
        <li class=" <?= empty($_SESSION['edit_post'] ) && !isset($_POST['edit_post'])  ? 'active' : '' ?> ">
            <a href="#tab-1">My Galleries</a>
        </li>
        <li class="tab-2-href-container  <?= !empty($_SESSION['edit_post']) && $tab2_active || isset($_POST['edit_post']) && $tab2_active ? 'active' : '' ?>">
            <a href="#tab-2"><?= $_SESSION['edit_post'] ?> Global Settings</a>
        </li>
        <li class="tab-3-href-container <?= !empty($active['active_hover']) ? 'active' : '' ?>">
            <a href="#tab-3"><?= $_SESSION['edit_post'] ?> Global Settings Hover</a>
        </li>
        <li class="tab-4-href-container <?= !empty($active['active_animation']) ? 'active' : '' ?>">
            <a href="#tab-4"><?= $_SESSION['edit_post'] ?> Global Settings Animate</a>
        </li>
        <li class="tab-5-custom-css-container <?= !empty($active['active_custom_css']) ? 'active' : '' ?>">
            <a href="#tab-5"><?= $_SESSION['edit_post'] ?> Custom Css</a>
        </li>
    </ul>

    <div class="tab-content">
        <div id="tab-5" class="tab-pane  custom_css_container <?= !empty($active['active_custom_css']) ? 'active' : '' ?>">

            <form method="post" action="options.php">
                <?php
                    settings_fields('gallery_plugin_globalSettings_settings');
                    do_settings_sections('gallery_global_settings');
                    submit_button("Save Custom Css",'secondary','submit_custom_css');
                ?>
            </form>

            <?php
                if (!empty($active['img_style_generator_custom_css'])){
                    include 'global_settings/globalSettingsAdminFront.php';
                }
            ?>

        </div>
        <div id="tab-1" class="tab-pane  <?= empty($_SESSION['edit_post'] ) && !isset($_POST['edit_post']) ? 'active' : '' ?> table_container">
            <?php
                $options = get_option('addGallery_settings') ?: array();

            echo '
                 <div class="black-lives-matter_container">
                    <h2 class="black-lives-matter">Your Galleries</h2>
                 </div>
            ';

            echo '
                 <table> .
                   <thead>
                     <tr>
                        <th>Gallery title</th>
                        <th class="center">Actions</th>
                     </tr>
                   </thead>
           ';
            echo " <tr>
                                    <td class='center'>Widgets</td>
                                    <td class='center'>
                                       <form method='post' action='' class='inline-block'>
                                             <input type='hidden' name='edit_post' value='widgets'>
                               
                        ";
            submit_button("Edit","primary small" ,"edit_submit",false);
            echo "         </form>                        
                                    </td>      
                               </tr>
                        ";

            foreach ($options as $option){

                echo "
                                    <tr>
                                        <td class='center'>{$option['gallery_title']}</td>
                                        <td class='center'>
                                           <form method='post' action='' class='inline-block'>
                                                 <input type='hidden' name='edit_post' value='".$option['gallery_title']."'>
                        ";
                submit_button("Edit","primary small" ,"edit_submit",false);
                echo "            </form> 
                                   
                                        </td>      
                                    </tr>
                        ";
            }
            echo '</table>';
            ?>
        </div>
        <div id="tab-2" class="tab-pane global_container  <?= !empty($_SESSION['edit_post']) && $tab2_active || isset($_POST['edit_post']) && $tab2_active ? 'active' : '' ?>">
            <form method="post" action="options.php">
                <?php
                    settings_fields('gallery_plugin_globalSettings_settings');
                    do_settings_sections('gallery_global_settings');
                    submit_button("Save Global Settings","primary" ,"submit",'true');
                echo '
                   <div class="default_container">
                      <div class="default_button">
                        <div class="plate"></div>
                        <div class="plate"></div>
                        <div class="plate"></div>
                        <div class="plate"></div>
                        <div class="plate"></div>
                        <div class="default_button__wrapper">
                          <span class="default_button__text">Remove styles</span>
                        </div>
                        <div class="default_button__box">
                          <div class="inner inner__top"></div>
                          <div class="inner inner__front"></div>
                          <div class="inner inner__bottom"></div>
                          <div class="inner inner__back"></div>
                          <div class="inner inner__left"></div>
                          <div class="inner inner__right"></div>
                        </div>
                      </div>
                   </div>
                ';
                ?>
            </form>
            <?php
                if (!empty($active['img_style_generator'])){
                    include 'global_settings/globalSettingsAdminFront.php';
                }
            ;?>
        </div>
        <div id="tab-3" class="tab-pane  hover_container <?= !empty($active['active_hover']) ? 'active' : ''  ?>">
            <form method="post" action="options.php">
                <?php
                    settings_fields('gallery_plugin_globalSettings_settings');
                    do_settings_sections('gallery_global_settings');
                    submit_button("Save Global Settings Hover",'secondary','submit_hover');
                echo '
                   <div class="default_container">
                      <div class="default_button">
                        <div class="plate"></div>
                        <div class="plate"></div>
                        <div class="plate"></div>
                        <div class="plate"></div>
                        <div class="plate"></div>
                        <div class="default_button__wrapper">
                          <span class="default_button__text">Remove styles</span>
                        </div>
                        <div class="default_button__box">
                          <div class="inner inner__top"></div>
                          <div class="inner inner__front"></div>
                          <div class="inner inner__bottom"></div>
                          <div class="inner inner__back"></div>
                          <div class="inner inner__left"></div>
                          <div class="inner inner__right"></div>
                        </div>
                      </div>
                   </div>
                ';
                ?>
            </form>

            <?php
                if (!empty($active['img_style_generator_hover'])){
                    include 'global_settings/globalSettingsAdminFront.php';
                }
            ?>
        </div>
        <div id="tab-4" class="tab-pane  animation_container <?= !empty($active['active_animation']) ? 'active' : '' ?>">
            <form method="post" action="options.php">
                <?php
                    settings_fields('gallery_plugin_globalSettings_settings');
                    do_settings_sections('gallery_global_settings');
                    submit_button("Save Global Settings Animation",'secondary','submit_animation');
                echo '
                   <div class="default_container">
                      <div class="default_button">
                        <div class="plate"></div>
                        <div class="plate"></div>
                        <div class="plate"></div>
                        <div class="plate"></div>
                        <div class="plate"></div>
                        <div class="default_button__wrapper">
                          <span class="default_button__text">Remove styles</span>
                        </div>
                        <div class="default_button__box">
                          <div class="inner inner__top"></div>
                          <div class="inner inner__front"></div>
                          <div class="inner inner__bottom"></div>
                          <div class="inner inner__back"></div>
                          <div class="inner inner__left"></div>
                          <div class="inner inner__right"></div>
                        </div>
                      </div>
                   </div>
                ';
                ?>
            </form>
            <?php
                if (!empty($active['img_style_generator_animation'])){
                    include 'global_settings/globalSettingsAdminFront.php';
                }
            ;?>
        </div>
    </div>
</div>
