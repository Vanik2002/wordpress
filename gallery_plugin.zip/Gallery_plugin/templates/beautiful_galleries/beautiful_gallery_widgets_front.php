<?php

$images_src = '';
$input = get_option('beautifulGalleries_settings') ? get_option('beautifulGalleries_settings') : array();

foreach ($input as $key) {
    $value = $key;
}

$images_src =  explode(',',$instance['image']);

if (empty($value)){ return; }

$count = 0;

echo '<div class="beautiful_galleries_container">';

if (strpos($value['widgets'] ,'beautiful_gallery_1_container')){
    echo '<div class="beautiful_gallery_1_container">';

    foreach ($images_src as $src){

        if (!empty($src)){
            echo '
                <figure class="beautiful_gallery_1">
                    <img src="' . $src . '" width="150" height="150" alt="">
                </figure>
            ';
        }

    }

    echo '</div>';
}

if (strpos($value['widgets'] ,'beautiful_gallery_2_container')){
    echo '<div class="beautiful_gallery_2_container">';

    foreach ($images_src as $src){

        if (!empty($src)){
            $count++;

            if($count > 36) {return;}

            echo '
                <div class="beautiful_gallery_2">
                    <img src="' . $src . '" width="150" height="150" alt="">
                </div>
            ';
        }

    }

    echo '</div>';
}

if (strpos($value['widgets'] ,'beautiful_gallery_3_container')) {
    echo '<div class="beautiful_gallery_3_container">';

    foreach ($images_src as $src) {

        if (!empty($src)) {
            $count++;

            if($count > 25) {return;}

            echo '
                <div class="beautiful_gallery_3_grid_block">
                    <div class="beautiful_gallery_3">
                        <img src="' . $src . '" alt="">
                    </div>
                </div>
            ';
        }

    }

    echo '</div>';
}

if (strpos($value['widgets'] ,'beautiful_gallery_4_container')) {
    echo '<div class="beautiful_gallery_4_container_div">';
    echo '<ul class="beautiful_gallery_4_container">';

    foreach ($images_src as $src) {

        if (!empty($src)) {
            $count++;

            if($count > 5) {return;}

            echo '
                <li class="beautiful_gallery_4">
                    <div style=" background: url('.$src.') center;  background-size: cover;" class="bg"></li>
                </li>
            ';
        }

    }

    echo '</ul>';
    echo '</div>';
}

if (strpos($value['widgets'] ,'beautiful_gallery_5_container')) {
    echo '<div class="beautiful_gallery_5_container">
                  <style>.beautiful_gallery_5:nth-of-type(5n + 1) { grid-column-start: 2 }</style>
            ';

    foreach ($images_src as $src) {

        if (!empty($src)) {
            $count++;

            if($count > 7) {return;}

            echo '
                <div class="beautiful_gallery_5">
                    <img src="' . $src . '" alt="">
                </div>
            ';
        }

    }

    echo '</div>';
}

$images_count = count($images_src) - 1;

if (strpos($value['widgets'] ,'beautiful_gallery_6_container')) {
    $images_count = min($images_count + 1, 10);

    echo '<style>
                @media (min-width: 60em){
                    .beautiful_galleries_container .beautiful_gallery_6_container .beautiful_gallery_6 {
                        grid-template-columns: repeat(' . $images_count . ', 8vw);
                        grid-template-rows: 20vh;
                    }
                }
         </style>
                 
        <div class="beautiful_gallery_6_container">
            <div class="beautiful_gallery_6">
    ';

                foreach ($images_src as $src) {

                    if (!empty($src)) {
                        $count++;

                        if($count > 10) {return;}

                        echo '<img src="' . $src . '">';
                    }

                }

    echo ' </div>
            </div>';
}

if (strpos($value['widgets'] ,'beautiful_gallery_7_container')) {

    echo '<div class="beautiful_gallery_7_container_div">
            <div class="beautiful_gallery_7_full-view"></div>
            <div class="beautiful_gallery_7_preview-list">
                <ul class="beautiful_gallery_7_container">
    ';
                    foreach ($images_src as $src) {

                        if (!empty($src)) {
                            $count++;

                            if($count > 10) {return;}

                            echo '
                                <li class="beautiful_gallery_7">
                                    <input type="radio" id="beautiful_gallery_7_tab-'.$count.'" name="gallery-group">
                                    <label for="beautiful_gallery_7_tab-'.$count.'">
                                        <div class="beautiful_gallery_7_tab">
                                            <img src="' . $src . '" alt=""/>
                                        </div>
                                    </label>
                                    <div class="beautiful_gallery_7_content">
                                        <img src="' . $src . '" alt=""/>
                                    </div>
                                </li>
                            ';
                        }

    }

    echo '
                </ul>
            </div>
        </div>
    ';
}

if (strpos($value['widgets'] ,'beautiful_gallery_8_container')) {

    echo '<div class="beautiful_gallery_8_container">';

            foreach ($images_src as $src) {

                if (!empty($src)) {
                    echo '<img src="' . $src . '">';
                }

            }

    echo ' </div>';

}

if (strpos($value['widgets'] ,'beautiful_gallery_9_container')) {

    echo '<div class="beautiful_gallery_9_container">';

            foreach ($images_src as $src) {

                if (!empty($src)) {
                    echo '<div class="beautiful_gallery_9">
                             <img src="' . $src . '" alt=""/>
                          </div>
                    ';
                }

            }

    echo '</div>';

}

if (strpos($value['widgets'] ,'beautiful_gallery_10_container')) {

    echo '<div class="beautiful_gallery_10_container">';

            foreach ($images_src as $src) {

                if (!empty($src)) {
                    $count++;

                    if($count > 5) {return;}

                    echo '<div class="beautiful_gallery_10">
                                <img src="' . $src . '" alt=""/>
                          </div>
                    ';
                }

            }

    echo '</div>
          <div class="beautiful_gallery_10_shadow"></div>
    ';

}

if (strpos($value['widgets'] ,'beautiful_gallery_11_container')) {
    echo '<div class="beautiful_gallery_11_container">
                    <div class="beautiful_gallery_11">
            ';
    foreach ($images_src as $src) {

        if (!empty($src)) {

            $count++;

            if($count > 9) {return;}

            echo '
                <input type="checkbox" id="beautiful_gallery_11_item'.$count.'" name="gallery-group">
                <label class="beautiful_gallery_11_item'.$count.'" for="beautiful_gallery_11_item'.$count.'" style="background: url('.$src.') center /cover"> </label>
            ';
        }

    }

    echo '  </div>
         </div>
    ';
}


if (strpos($value['widgets'] ,'beautiful_gallery_12_container')) {

    echo '<div class="beautiful_gallery_12_container">';

            foreach ($images_src as $src) {

                if (!empty($src)) {
                    echo '<div class="beautiful_gallery_12">
                             <img src="' . $src . '" alt=""/>
                         </div>
                    ';
                }

            }

    echo '</div>';

    echo '<script>
            const observer=new IntersectionObserver(f,{threshold:[0,1]});function f(e){for(let t of e)t.isIntersecting&&t.intersectionRatio>=1?t.target.classList.toggle("inbound",!0):t.target.classList.toggle("inbound",!1)}const beautiful_gallery_12Els=Array.from(document.querySelectorAll(".beautiful_gallery_12"));for(const itemEl of beautiful_gallery_12Els)observer.observe(itemEl);
          </script>
    ';

}

if (strpos($value['widgets'] ,'beautiful_gallery_13_container')) {
    echo '<div class="beautiful_gallery_13_container">
            <div class="beautiful_gallery_13">
    ';
                foreach ($images_src as $src) {

                    if (!empty($src)) {
                        $count++;
                        $checked = $count === 1 ? 'checked' : '';

                        if($count < 20) {
                            echo '
                                <input type="radio" id="beautiful_gallery_13c'.$count.'" name="gallery-group" '.$checked.'>
                                <label class="beautiful_gallery_13t" for="beautiful_gallery_13c'.$count.'">
                                    <img src="' . $src . '" alt=""/>
                                </label>
                            ';
                        }

                    }

                }
    echo '
            </div>
          </div>
    ';

    ?>
        <script>
            const els=document.querySelectorAll("[type='radio']");for(const el of els)el.addEventListener("input",e=>reorder(e.target,els));function reorder(e,t){let r=t.length,l=0;for(let o of t){let s=o.nextElementSibling;o===e?(s.style.setProperty("--w","100%"),s.style.setProperty("--l","0")):(s.style.setProperty("--w",`${100/(r-1)}%`),s.style.setProperty("--l",`${100*l/(r-1)}%`),l+=1)}}reorder(els[0],els);
        </script>
    <?php
}

if (strpos($value['widgets'] ,'beautiful_gallery_14_container')) {
    echo '   
                 <div class="beautiful_gallery_14_container">             
            ';

    foreach ($images_src as $src) {

        if (!empty($src)) {
            echo '
                  <a target="_blank" class="beautiful_gallery_14" style="background: url(' . $src . ') center /cover"></a>    
            ';
        }

    }

    echo '</div> ';

}

if (strpos($value['widgets'] ,'beautiful_gallery_15_container')) {

    echo '
          <div class="beautiful_gallery_15_container">
            <div class="beautiful_gallery_15">
    ';
                foreach ($images_src as $src) {

                    if (!empty($src)) {

                        echo '<div class="beautiful_gallery_15_box">
                                <img src="' . $src . '" alt=""/>
                                 <div class="beautiful_gallery_15_overlay beautiful_gallery_15_ovrl-left"></div>
                                 <div class="beautiful_gallery_15_overlay beautiful_gallery_15_ovrl-right"></div>
                                 <div class="beautiful_gallery_15_locker"><i class="beautiful_gallery_15_arrow fa fa-arrows-h" aria-hidden="true"></i></div>
                              </div>        
                        ';

                    }

                }

    echo '  </div>
          </div>
    ';

    ?>
        <script>
            jQuery(function(){jQuery(".beautiful_gallery_15_box").on("mousedown",function(){let l=jQuery(this).children("div");jQuery(this).children(".beautiful_gallery_15_locker").hide();for(let e=0;e<l.length;e++)jQuery(l[e]).hasClass("beautiful_gallery_15_ovrl-left")&&jQuery(l[e]).toggleClass("beautiful_gallery_15_move-right"),jQuery(l[e]).hasClass("beautiful_gallery_15_ovrl-right")&&jQuery(l[e]).toggleClass("beautiful_gallery_15_move-left");jQuery(this).off()})});
        </script>
    <?php

}

if (strpos($value['widgets'] ,'beautiful_gallery_16_container')) {
    echo '<div class="beautiful_gallery_16">
            <div class="beautiful_gallery_16__gallery">          
    ';
                foreach ($images_src as $src) {

                    if (!empty($src)) {
                        $count++;

                        if($count < 25) {
                            echo '<div class="beautiful_gallery_16__placeholder" data-defaultValue="' . $src . '"></div>';
                        }

                    }

                }

    echo '  </div>
          </div>
    ';

    ?>
        <script>
            "use strict";jQuery(document).ready(function(){let a=[];jQuery(".beautiful_gallery_16__placeholder").each(function(){a.push(jQuery(this).attr("data-defaultValue"))});let t=jQuery(".beautiful_gallery_16__gallery"),l=[],e=window.requestAnimationFrame||function(a){setTimeout(a,1e3/60)};t.html("");for(let r=1;r<=4;r++){l[r-1]=[];for(let i=1;i<=6;i++)t.append(`<div class="show-front beautiful_gallery_16__part beautiful_gallery_16__part-${r}-${i}" row="${r}" col="${i}"><div class="beautiful_gallery_16__part-back"><div class="beautiful_gallery_16__part-back-inner"></div></div><div class="beautiful_gallery_16__part-front"></div></div>`),l[r-1][i-1]=new c}let n=jQuery(".beautiful_gallery_16__part"),u=jQuery(".beautiful_gallery_16__part-back-inner");for(let o=0;o<n.length;o++)n.find(".beautiful_gallery_16__part-front").eq(o).css("background-image",`url(${a[o]})`);function c(){this.showing="front"}t.on("click",".beautiful_gallery_16__part-front",function(){u.css("background-image",jQuery(this).css("background-image"));let a=+jQuery(this).closest(".beautiful_gallery_16__part").attr("row"),t=+jQuery(this).closest(".beautiful_gallery_16__part").attr("col");(function a(t,e){!(t>4)&&!(e>6)&&!(t<=0)&&!(e<=0)&&"back"!==l[t-1][e-1].showing&&(jQuery(".beautiful_gallery_16__part-"+t+"-"+e).removeClass("show-front"),l[t-1][e-1].showing="back",setTimeout(function(){a(t+1,e),a(t-1,e),a(t,e+1),a(t,e-1)},150))})(a,t)}),t.on("click",".beautiful_gallery_16__part-back",function(){"back"===l[0][0].showing&&"back"===l[0][5].showing&&"back"===l[3][0].showing&&"back"===l[3][5].showing&&(setTimeout(function(){for(let a=1;a<=4;a++)for(let t=1;t<=6;t++)l[a-1][t-1].showing="front"},150+150*n.length/10),function a(t,l){t>=l||(n.eq(t).addClass("show-front"),e(function(){a(t+1)}))}(0,n.length))})});
        </script>
    <?php

}

if (strpos($value['widgets'] ,'beautiful_gallery_17_container')) {
    echo '<div class="beautiful_gallery_17_container_div">
            <ul class="beautiful_gallery_17_container">
    ';
                foreach ($images_src as $src) {

                    if (!empty($src)) {
                        echo '
                              <li class="beautiful_gallery_17">
                                  <img src="' . $src . '" alt="">
                              </li>   
                       ';
                    }

                }

    echo '    </ul>
          </div>
    ';
}

if (strpos($value['widgets'] ,'beautiful_gallery_18_container')) {
    echo '<div class="beautiful_gallery_18_container">
            <div class="beautiful_gallery_18_grid_container">       
    ';
                foreach ($images_src as $src) {

                    if (!empty($src)) {
                        echo '<div class="beautiful_gallery_18">
                                <img src="' . $src . '" alt=""/>
                              </div>        
                        ';
                    }

                }

    echo '  </div>
         </div>
    ';

}

echo '</div>';

?>


