window.addEventListener("load", function (){

    let tabs = document.querySelectorAll("ul.nav-tabs > li");

    for (let i = 0; i < tabs.length; i++){
        tabs[i].addEventListener("click",switchTab);
    }

    function switchTab(event){
        
        event.preventDefault();
        document.querySelector("ul.nav-tabs li.active").classList.remove("active");
        document.querySelector(".tab-pane.active").classList.remove("active");
        let clickedTab = event.currentTarget;
        let anchor = event.target;
        let activePaneID = anchor.getAttribute("href");
        clickedTab.classList.add("active");
        document.querySelector(activePaneID).classList.add("active");
        
    }

})

jQuery(document).ready(function ($){

    let submit = $('#submit');

    let save_gallery = $('#save_gallery');
    let gallery_column = $('.gallery_container .column');
    let hover_submit = $('.hover_container #submit_hover');
    let animation_options = $(".animation_container .options");
    let animation_submit = $('.animation_container #submit_animation');
    let custom_css_submit = $('.custom_css_container #submit_custom_css');

    $(document).on('click','.upload',function (e){

        e.preventDefault();
        let $button = $(this);
        let file_frame = wp.media.frames.file_frame = wp.media({
            title: 'Select or Upload an Image',
            library:{
                type:'image'
            },
            button: {
                text: 'Select Image'
            },
            multiple: true
        });

        file_frame.on('select',function (){

            let gallery_images_src = $button.siblings('input').val();
            gallery_images_src = gallery_images_src.split(',')
            let attachment = file_frame.state().get('selection').toJSON();

            for (let i = 0; i <  attachment.length; i++){

                gallery_images_src.push(attachment[i].url)

                if (gallery_images_src[i] === ''){
                    gallery_images_src.splice(i, 1)
                }

            }

            $button.siblings('input').val(gallery_images_src)

        })

        file_frame.open()

    })



    $(document).on('click','.js-image-upload',function (e){

        e.preventDefault();
        let $button = $(this);

        let file_frame = wp.media.frames.file_frame = wp.media({
            title: 'Select or Upload an Image',
            library:{
                type:'image'
            },
            button: {
                text: 'Select Image'
            },
            multiple: true
        });

        file_frame.on('select',function (){

            let gallery_images_src = $button.siblings('input').val();
            gallery_images_src = gallery_images_src.split(',')
            let attachment = file_frame.state().get('selection').toJSON();

            for (let i = 0; i <  attachment.length; i++){

                gallery_images_src.push(attachment[i].url)

                if (gallery_images_src[i] === ''){
                    gallery_images_src.splice(i, 1)
                }

            }

            $button.siblings('input').val(gallery_images_src)
            $('.widget_checkbox_update').trigger('click');

        })

        file_frame.open()

    })

    $('.global_container tr:has(.hover) input').removeAttr('id');
    $('.global_container tr:has(.animation)  input').removeAttr('id');
    $('.global_container tr:has(#custom_css)  input').removeAttr('id');
    $('.hover_container tr input:not(input.hover)').removeAttr('id');
    $('.animation_container tr input:not(input.animation_container,input.animation)').removeAttr('id');
    $('.custom_css_container tr:not(tr:has(.custom_css)) input').removeAttr('id');
    animation_options.siblings('input').prop('disabled', true);

    $(".options").click(function () {

        let border_size = $(this).val()

        if (border_size !== '') {
            if (border_size === 'none') {
                border_size = '';
            }
            $(this).siblings('input').val(border_size)
        }

        $(this).siblings('.options_type').prop('disabled', false);

    })

    animation_options.click(function (){

        let border_size = $(this).val()

        if (border_size !== '') {
            if (border_size === 'none'){
                border_size = '';
            }
            $(this).siblings('input').val(border_size)
        }

        $(this).siblings('.options_type').prop('disabled', false);

        if ( $(this).siblings('input').val()!== ''){
            $('select.options').not(this).prop('disabled', true);
        }
        else{
            $('select.options').not(this).prop('disabled', false);
            $('.options').siblings('input').val('')
        }

    })

    $(".options_type").click(function (){

        let border_size = $(this).siblings('.options').val()
        let border_container = $(this).val()

        if (border_size !== '' && border_container !== null &&  border_size !== null && border_size !== 'none') {
            if (border_size === 'none'){
                border_size = '';
                border_container = ''
            }

            $(this).siblings('input').val(`${border_size}(${border_container})`)
        }

    })

    $("#image_align_slct").click(function (){

        let border_size = $(this).val()

        if (border_size !== '') {
            $(this).siblings('input').val(border_size)
        }

    })

    submit.mouseenter(function (){
        $(".options").siblings('input').prop('disabled', false);
        $('#active_hover').prop('checked', false);
        $('#active_animation').prop('checked', false);
        $('#active_custom_css').prop('checked', false)

    })
    hover_submit.mouseenter(function (){

        $(".options").siblings('input').prop('disabled', false);
        $('#active_hover').prop('checked', true);
        $('#active_animation').prop('checked', false);
        $('#active_custom_css').prop('checked', false);

    })

    animation_submit.mouseenter(function (){

        $(".options").siblings('input').prop('disabled', false);
        $('#active_hover').prop('checked', false);
        $('#active_custom_css').prop('checked', false);
        $('#active_animation').prop('checked', true);

    })

    custom_css_submit.mouseenter(function (){

        $('#active_hover').prop('checked', false);
        $('#active_animation').prop('checked', false);
        $('#active_custom_css').prop('checked', true);

    })

    save_gallery.mouseenter(function (){

        let add_image = $(".add_image");
        add_image.prop('disabled', false);

    })

    submit.mouseleave(function (){
        $(".options").siblings('input').prop('disabled', true);
    })

    hover_submit.mouseleave(function (){
        $(".options").siblings('input').prop('disabled', true);
    })

    animation_submit.mouseleave(function (){
        $(".options").siblings('input').prop('disabled', true);
    })
    custom_css_submit.mouseleave(function (){
        $('#active_custom_css').prop('checked', false);
    })

    save_gallery.mouseleave(function (){

        let add_image = $(".add_image");
        add_image.prop('disabled', true);

    })

    $(document).on('click','.edit-widgets-header__actions .components-button',function () {

        setTimeout(function (){
            location.reload();
        },5000)

    })

    $(document).on('click','.widget-content .column_delete',function () {

        let image_upload = $(".image-upload");
        let img_delete = confirm('Do you want to delete this image?')

        if (img_delete){
            let value = image_upload.val();
            let value_arr = value.split(',')
            let src = $(this).siblings('img').attr('src')

            for (let i = 0; i < value_arr.length; i++){
                if (value_arr[i] === src){
                    value_arr.splice(i, 1);
                }
            }

            value = value_arr.toString()
            image_upload.val(value)
            $(this).parents('.widget-content .column').hide();
            $('.widget_checkbox_update').trigger('click');
        }

    })

    $(document).on('mouseenter','.widget-content .column',function () {
        $(this).children('.column_delete').show();
    })

    $(document).on('mouseleave','.widget-content .column',function () {
        $(this).children('.column_delete').hide();
    })

    $(document).on('mouseenter','.widget-content .image-upload',function () {
        $('.image-upload').prop('disabled',true)
    })

    $(document).on('mouseleave','.widget-content .image-upload',function () {
        $('.image-upload').prop('disabled',false)
    })

    gallery_column.mouseenter(function (){
        $(this).children('.column_delete').show();
    })

    gallery_column.mouseleave(function (){
        $(this).children('.column_delete').hide();
    })

    $('.gallery_container .column .column_delete').click(function (){

        let add_image = $(".add_image");
        let img_delete = confirm('Do you want to delete this image?')

        if (img_delete) {
            let value = add_image.val();
            let value_arr = value.split(',')
            let src = $(this).siblings('img').attr('src')

            for (let i = 0; i < value_arr.length; i++) {

                if (value_arr[i] === src) {
                    value_arr.splice(i, 1);
                }

            }

            value = value_arr.toString()
            add_image.val(value)
            $(this).parents('.gallery_container .column').hide();
        }

    })

    $('.gallery_media_widget .gallery_image_container ').click(function (){

        let img_delete = confirm('Do you want to delete this image?');
        if (img_delete){
            $(this).hide();
        }

    })

    function copyToClipboard(element) {

        let $temp = $("<input>");
        $("body").append($temp);
        $temp.val($(element).text()).select();
        document.execCommand("copy");
        $temp.remove();

    }

    $('.shortcode_container h2').click(function (){

        let copied_container = $('.copied_container');
        copied_container.show(2000);
        copyToClipboard(this)
        copied_container.hide(4000);

    })

    $('form .default_container').click(function (){

       let input = $(this).siblings('.form-table').children('tbody').children('tr').children('td').children('input')
       let remove_styles = confirm('Do you want to remove these styles?');

       if (remove_styles){

           $('.global_container.active #image_width').attr('data-parent','remove_styles')
           $('.hover_container.active #image_width_hover').attr('data-parent','remove_styles')

           $(input).each(function (){

               if ($(this).hasClass('animation')){
                   $(this).siblings('.options').prop('disabled',false)
               }
               if ($(this).val() !== null && $(this).attr('id') !== undefined){
                        $(this).val('');
               }

           })

           if ($(this).parents('.global_container').hasClass('active')){

               $('.gallery_container').css
               ({
                   'width': `100%`,
                   'z-index' : `0`,
               })

               $('.gallery_container:has(.gallery_image_container)').css
               ({
                   'border': `0`,
               })

               $('.gallery_image_container ').css
               ({
                   'width': `25%`,
                   'margin-top': `0`,
                   'margin-bottom': `0`,
               })

               $('.gallery_image_container img').css
               ({
                   'float': `unset`,
                   'width': `150px`,
                   'height': `150px`,
                   'padding': `0`,
                   'opacity': `1`,
                   'border'     : `0`,
                   'filter'     : `none`,
                   'transform'  : `translate(0,0)
                                   scale(1,1)
                                   skew(0,0)
                                   rotate(0)`,
                   'box-shadow' : '0 0 0 0'
               })

               $('.gallery_container.background-color').css
               ({
                   'background-color': ``,
               })

               $('.gallery_image_container a').attr('href','#')
               $('.gallery_image_container a img').attr('class','')


           }

       }
       else {
           $('.global_container #image_width').attr('data-parent','')
           $('.hover_container #image_width_hover').attr('data-parent','')
       }


    })

    $('.beautiful_gallery_checkbox').click(function (){

        let beautiful_gallery_value = $(this).prop('checked') ? $(this).attr('id') : '';
        let beautiful_gallery_boolean =  false;

        if ($(this).prop('checked')){
            beautiful_gallery_boolean = true;
        }

        $('.beautiful_gallery_data').each(function (){
            let post_data = $('#post_data').val()

            if ($(this).attr('id') === post_data){
               let post_id = $(this).attr('id')
               $(this).val(`${post_id},${beautiful_gallery_value}`)
                if (!beautiful_gallery_boolean){
                    $(this).val('');
                }
            }
        })

        $('.beautiful_gallery_checkbox').not($(this)).prop('checked',false);

    })

    $('.beautiful_gallery.active tr .regular-text').prop('disabled',true)

    $("input#beautiful_gallery").mouseenter(function (){
        $('.beautiful_gallery.active tr .regular-text').prop('disabled',false)
    })

    $("input#beautiful_gallery").mouseleave(function (){
        $('.beautiful_gallery.active tr .regular-text').prop('disabled',true)
    })

    $('.my_img_color').on('input',function (){
        $(this).parent('label').siblings('input').val($(this).val())
        console.log( $('#write_bg_color').val())
    })

})


jQuery( document ).ready( function() {

    let cssEditorSettings = wp.codeEditor.defaultSettings ? _.clone( wp.codeEditor.defaultSettings ) : {};
    let jsEditorSettings = wp.codeEditor.defaultSettings ? _.clone( wp.codeEditor.defaultSettings ) : {};

    cssEditorSettings.codemirror = _.extend(
        {},
        cssEditorSettings.codemirror,
        {
            lineNumbers:true,
            mode:"css",
            tabSize:6,
            indentUnit: 4,
            theme:"dracula",
            lineWrapping: true
        }
    );

    jsEditorSettings.codemirror = _.extend(
        {},
        jsEditorSettings.codemirror,
        {
            lineNumbers:true,
            mode:"javascript",
            tabSize:6,
            indentUnit: 4,
            theme:"dracula",
            lineWrapping: true
        }
    );

    if (jQuery('.wp-admin .custom_js_container').length !== 0){
            wp.codeEditor.initialize( 'custom_Js', jsEditorSettings );
    }
    else if(jQuery('.wp-admin .custom_css_container').length !== 0){
        wp.codeEditor.initialize('custom_css', cssEditorSettings);
    }

});



